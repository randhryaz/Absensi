
<?php
require 'config.koneksi.php';

$tab_token = $_GET['tab_token'] ?? '';
wajibRole('guru');

$guru_id = (int)($_SESSION['user']['id'] ?? 0);
$kelas_id = (int)($_REQUEST['kelas_id'] ?? 0);

// Ambil tanggal mulai dan selesai
$tanggalMulai = $_POST['tanggal_mulai'] ?? $_GET['tanggal_mulai'] ?? date('Y-m-d');
$tanggalSelesai = $_POST['tanggal_selesai'] ?? $_GET['tanggal_selesai'] ?? date('Y-m-d');

// Background dashboard guru
$bgStyle = "background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #60a5fa 100%);";

try {
    $stmtBg = $pdo->prepare("SELECT value_text FROM settings WHERE key_name = 'bg_guru_dashboard'");
    $stmtBg->execute();
    $customBgGuru = $stmtBg->fetchColumn();

    if ($customBgGuru && file_exists($customBgGuru)) {
        $bgStyle = "background: url('" . e($customBgGuru) . "') no-repeat center center fixed; background-size: cover;";
    }
} catch (Throwable $e) {}

// Cek Guru BK
$user = $_SESSION['user'] ?? [];
$userRole = $user['role'] ?? '';
$userName = $user['nama'] ?? '';
$isBK = ($userRole === 'bk' || stripos($userName, 'bk') !== false);

// Ambil data kelas
if ($isBK) {
    $stmt = $pdo->prepare("SELECT * FROM kelas WHERE id = ?");
    $stmt->execute([$kelas_id]);
} else {
    $stmt = $pdo->prepare("SELECT * FROM kelas WHERE id = ? AND guru_id = ?");
    $stmt->execute([$kelas_id, $guru_id]);
}

$kelas = $stmt->fetch();

if (!$kelas) {
    exit("Kelas tidak ditemukan atau akses ditolak.");
}

$pesan = '';
$jenis = 'info';

// Proses penyimpanan absensi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cekCsrf();

    $tglMulai = $_POST['tanggal_mulai'] ?? '';
    $tglSelesai = $_POST['tanggal_selesai'] ?? '';

    $d1 = DateTime::createFromFormat('!Y-m-d', $tglMulai);
    $d2 = DateTime::createFromFormat('!Y-m-d', $tglSelesai);

    if (
        !$d1 || !$d2 ||
        $d1->format('Y-m-d') !== $tglMulai ||
        $d2->format('Y-m-d') !== $tglSelesai
    ) {
        $pesan = "Format rentang tanggal tidak valid!";
        $jenis = 'danger';

    } elseif ($d1 > $d2) {
        $pesan = "Tanggal mulai tidak boleh lebih besar dari tanggal selesai!";
        $jenis = 'danger';

    } else {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("SELECT id FROM siswa WHERE kelas_id = ?");
            $stmt->execute([$kelas_id]);
            $siswa_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $simpan = $pdo->prepare("
                INSERT INTO absensi
                (siswa_id, tanggal, status, keterangan)
                VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    status = VALUES(status),
                    keterangan = VALUES(keterangan)
            ");

            $period = new DatePeriod(
                $d1,
                new DateInterval('P1D'),
                (clone $d2)->modify('+1 day')
            );

            foreach ($period as $date) {
                $currentDate = $date->format('Y-m-d');

                foreach ($siswa_ids as $id) {
                    $status = $_POST['status'][$id] ?? '';
                    $ket = trim($_POST['keterangan'][$id] ?? '');

                    if (!in_array($status, ['Hadir', 'Izin', 'Sakit', 'Alpa'], true)) {
                        throw new Exception("Status absensi siswa ID $id tidak valid.");
                    }

                    $simpan->execute([
                        (int)$id,
                        $currentDate,
                        $status,
                        $ket
                    ]);
                }
            }

            $pdo->commit();

            $pesan = "Berhasil menyimpan absensi untuk rentang tanggal $tglMulai s.d. $tglSelesai!";
            $jenis = 'success';

            $tanggalMulai = $tglMulai;
            $tanggalSelesai = $tglSelesai;

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $pesan = "Gagal menyimpan: " . $e->getMessage();
            $jenis = 'danger';
        }
    }
}

// Ambil data siswa
$stmt = $pdo->prepare("
    SELECT s.id, s.nis, s.nama,
           a.status, a.keterangan
    FROM siswa s
    LEFT JOIN absensi a
        ON a.siswa_id = s.id
        AND a.tanggal = ?
    WHERE s.kelas_id = ?
    ORDER BY s.nama
");

$stmt->execute([$tanggalMulai, $kelas_id]);
$data = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Absensi Fleksibel - SMK MUHAYO</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="style.css" rel="stylesheet">

<style>
body {
    <?= $bgStyle ?>
    min-height: 100vh;
    color: #1e293b;
}

.custom-container {
    max-width: 1000px;
}

.card {
    border: none;
    border-radius: 14px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
    background-color: #ffffff;
}

h3 {
    color: #ffffff;
    font-weight: 700;
}

.table-container {
    background: #ffffff;
    border-radius: 10px;
    overflow: hidden;
}
</style>
</head>

<body>

<div class="container custom-container py-5">

<!-- TOMBOL KEMBALI MERAH -->
<a href="guru.dashboard.php?tab_token=<?= urlencode($tab_token) ?>"
   class="btn btn-danger btn-sm px-4 mb-3">
    ← Kembali
</a>

<h3 class="my-3">
    Absensi Kelas: <?= e($kelas['nama_kelas']) ?>
    <?= $isBK ? '(Mode BK)' : '' ?>
</h3>

<?php if ($pesan): ?>
<div class="alert alert-<?= e($jenis) ?> shadow-sm">
    <?= e($pesan) ?>
</div>
<?php endif; ?>

<div class="card p-4 mb-4 shadow-sm">

<form method="GET" class="row g-3 align-items-end">

<input type="hidden" name="kelas_id" value="<?= $kelas_id ?>">
<input type="hidden" name="tab_token" value="<?= e($tab_token) ?>">

<div class="col-md-5">
<label class="form-label fw-semibold">Dari Tanggal (Mulai)</label>
<input
    type="date"
    name="tanggal_mulai"
    class="form-control"
    value="<?= e($tanggalMulai) ?>"
    required
>
</div>

<div class="col-md-5">
<label class="form-label fw-semibold">Sampai Tanggal (Selesai)</label>
<input
    type="date"
    name="tanggal_selesai"
    class="form-control"
    value="<?= e($tanggalSelesai) ?>"
    required
>
</div>

<div class="col-md-2">
<button type="submit" class="btn btn-primary w-100 fw-semibold">
    Muat
</button>
</div>

</form>
</div>

<form method="POST" class="card p-4 shadow-sm">

<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">
<input type="hidden" name="kelas_id" value="<?= $kelas_id ?>">
<input type="hidden" name="tanggal_mulai" value="<?= e($tanggalMulai) ?>">
<input type="hidden" name="tanggal_selesai" value="<?= e($tanggalSelesai) ?>">

<div class="d-flex justify-content-between align-items-center mb-3">

<h5 class="text-primary fw-bold mb-0">
    📋 Daftar Siswa
</h5>

<span class="badge bg-info text-dark">
    Rentang: <?= e($tanggalMulai) ?> s.d. <?= e($tanggalSelesai) ?>
</span>

</div>

<div class="table-responsive table-container mb-4">

<table class="table table-hover align-middle mb-0">

<thead class="table-light">
<tr>
<th style="width: 35%;">Nama & NIS</th>
<th style="width: 35%;">Status (Seragam untuk Rentang Ini)</th>
<th style="width: 30%;">Keterangan</th>
</tr>
</thead>

<tbody>

<?php foreach ($data as $s): ?>

<tr>

<td>
<div class="fw-semibold"><?= e($s['nama']) ?></div>
<small class="text-muted"><?= e($s['nis']) ?></small>
</td>

<td>
<select name="status[<?= (int)$s['id'] ?>]" class="form-select" required>

<option value="">Pilih Status</option>

<?php foreach (['Hadir', 'Izin', 'Sakit', 'Alpa'] as $v): ?>

<option
    value="<?= e($v) ?>"
    <?= ($s['status'] ?? '') === $v ? 'selected' : '' ?>
>
    <?= e($v) ?>
</option>

<?php endforeach; ?>

</select>
</td>

<td>
<input
    name="keterangan[<?= (int)$s['id'] ?>]"
    class="form-control"
    value="<?= e($s['keterangan'] ?? '') ?>"
    placeholder="Keterangan (opsional)"
>
</td>

</tr>

<?php endforeach; ?>

<?php if (!$data): ?>
<tr>
<td colspan="3" class="text-center text-muted py-3">
    Belum ada data siswa di kelas ini.
</td>
</tr>
<?php endif; ?>

</tbody>
</table>
</div>

<button type="submit" class="btn btn-success px-4 fw-semibold">
    💾 Simpan Absensi untuk Rentang Tanggal
</button>

</form>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
