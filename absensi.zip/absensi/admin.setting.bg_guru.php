<?php
require 'config.koneksi.php';
wajibRole('admin');

$pesan = '';
$jenis = 'info';

// Pastikan folder uploads ada
if (!is_dir('uploads')) {
    mkdir('uploads', 0777, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cekCsrf();

    try {
        if (isset($_FILES['bg_guru']) && $_FILES['bg_guru']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['bg_guru']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'webp'];
            
            if (!in_array($ext, $allowed)) {
                throw new Exception("Format file tidak valid! Gunakan JPG, JPEG, PNG, atau WEBP.");
            }

            $namaFile = 'bg_guru_dashboard_' . time() . '.' . $ext;
            move_uploaded_file($_FILES['bg_guru']['tmp_name'], 'uploads/' . $namaFile);
            
            // Simpan ke database dengan key khusus 'bg_guru_dashboard'
            $stmt = $pdo->prepare("INSERT INTO settings (key_name, value_text) VALUES ('bg_guru_dashboard', ?) ON DUPLICATE KEY UPDATE value_text = ?");
            $stmt->execute(['uploads/' . $namaFile, 'uploads/' . $namaFile]);

            $pesan = "Background Dashboard Guru berhasil diperbarui!";
            $jenis = "success";
        } else {
            throw new Exception("Pilih file foto terlebih dahulu!");
        }
    } catch (Throwable $e) {
        $pesan = $e->getMessage();
        $jenis = "danger";
    }
}

// Ambil background saat ini dari database
$bgDashboardGuru = $pdo->query("SELECT value_text FROM settings WHERE key_name = 'bg_guru_dashboard'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pengaturan Background Dashboard Guru - SMK Muhammadiyah 2 Yogyakarta</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="style.css" rel="stylesheet">
<style>
    body {
        background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #60a5fa 100%);
        min-height: 100vh;
        color: #1e293b;
    }
    .custom-container {
        max-width: 650px;
    }
    .card {
        border: none;
        border-radius: 14px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        background-color: #ffffff;
    }
    .back-link {
        color: #e2e8f0;
        text-decoration: none;
        font-weight: 500;
        display: inline-block;
        margin-bottom: 15px;
        transition: color 0.2s;
    }
    .back-link:hover {
        color: #ffffff;
        text-decoration: underline;
    }
    h3 {
        color: #ffffff;
        font-weight: 700;
    }
</style>
</head>
<body>

<div class="container custom-container py-5">
<a href="admin.dashboard.php" class="back-link" style="display:inline-block;background:#dc3545;color:#fff;text-decoration:none;padding:7px 13px;border-radius:6px;width:fit-content;margin-bottom:15px;font-weight:500">← Kembali</a>
<h3 class="my-3">Pengaturan Background Dashboard Guru</h3>

<?php if ($pesan): ?>
<div class="alert alert-<?= e($jenis) ?> shadow-sm"><?= e($pesan) ?></div>
<?php endif; ?>

<div class="card p-4 shadow-sm">
<form method="POST" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">

<div class="mb-4">
<label class="form-label fw-semibold">Pilih Foto Background Baru</label>
<?php if ($bgDashboardGuru): ?>
<div class="mb-3">
<p class="text-muted small mb-1">Background saat ini:</p>
<img src="<?= e($bgDashboardGuru) ?>" alt="Preview BG" style="max-height: 120px; border-radius: 8px;" class="shadow-sm border">
</div>
<?php endif; ?>
<input type="file" name="bg_guru" class="form-control" accept=".jpg, .jpeg, .png, .webp" required>
<small class="text-muted">Format yang diizinkan: JPG, JPEG, PNG, WEBP</small>
</div>

<button type="submit" class="btn btn-primary px-4 fw-semibold">💾 Simpan Perubahan</button>
</form>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>