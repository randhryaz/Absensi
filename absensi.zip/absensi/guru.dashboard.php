<?php
require 'config.koneksi.php';
wajibRole('guru');

// Ambil background khusus dashboard guru dari database (jika ada)
$bgStyle = "background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #60a5fa 100%);";
try {
    $stmt = $pdo->prepare("SELECT value_text FROM settings WHERE key_name = 'bg_guru_dashboard'");
    $stmt->execute();
    $customBg = $stmt->fetchColumn();

    if ($customBg && file_exists($customBg)) {
        $bgStyle = "background: url('" . e($customBg) . "') no-repeat center center fixed; background-size: cover;";
    }
} catch (Throwable $e) {}

// Ambil data user yang sedang login dengan aman
$user = $_SESSION['user'] ?? [];
$userName = $user['nama'] ?? 'Guru';
$userRole = $user['role'] ?? '';

// Cek apakah user adalah Guru BK (berdasarkan role atau nama yang mengandung 'bk')
$isBK = ($userRole === 'bk' || stripos($userName, 'bk') !== false);

if ($isBK) {
    // Guru BK bisa melihat SEMUA kelas di sekolah beserta jumlah siswanya
    $stmt = $pdo->prepare("
        SELECT k.id, k.nama_kelas, COUNT(s.id) AS jumlah
        FROM kelas k
        LEFT JOIN siswa s ON s.kelas_id = k.id
        GROUP BY k.id, k.nama_kelas
        ORDER BY k.nama_kelas
    ");
    $stmt->execute();
} else {
    // Guru biasa hanya melihat kelas yang diampunya
    $stmt = $pdo->prepare("
        SELECT k.id, k.nama_kelas, COUNT(s.id) AS jumlah
        FROM kelas k
        LEFT JOIN siswa s ON s.kelas_id = k.id
        WHERE k.guru_id = ?
        GROUP BY k.id, k.nama_kelas
    ");
    $stmt->execute([$user['id'] ?? 0]);
}
$data = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dashboard Guru / BK - SMK Muhammadiyah 2 Yogyakarta</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="style.css" rel="stylesheet">
<style>
    body {
        <?= $bgStyle ?>
        min-height: 100vh;
        color: #1e293b;
    }
    .custom-container {
        max-width: 1100px;
    }
    .card {
        border: none;
        border-radius: 14px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        background-color: #ffffff;
        transition: transform 0.2s;
    }
    .card:hover {
        transform: translateY(-5px);
    }
    .navbar {
        background-color: rgba(0, 0, 0, 0.2);
        backdrop-filter: blur(10px);
    }
    .navbar-brand {
        color: #ffffff !important;
        font-weight: 700;
    }
    h3 {
        color: #ffffff;
        font-weight: 700;
    }
</style>
</head>
<body>

<nav class="navbar navbar-dark px-4 py-3">
<span class="navbar-brand">🎓 SMK Muhammadiyah 2 Yogyakarta <?= $isBK ? '(BK Panel)' : '' ?></span>
<a href="auth.logout.php" class="btn btn-light btn-sm fw-semibold text-danger">Logout</a>
</nav>

<div class="container custom-container py-5">
<h3 class="mb-1">Halo, <?= e($userName) ?> 👋</h3>
<p class="text-white mb-4">
    <?= $isBK ? 'Anda masuk sebagai Guru BK. Berikut adalah daftar seluruh kelas di sekolah untuk pemantauan absensi.' : 'Daftar kelas yang Anda ampu pada sistem absensi.' ?>
</p>

<div class="row g-4">
<?php foreach($data as $k): ?>
<div class="col-md-4">
<div class="card p-4 h-100 d-flex flex-column justify-content-between">
<div>
<h4 class="text-primary fw-bold mb-2"><?= e($k['nama_kelas']) ?></h4>
<p class="text-muted small mb-4">👥 <strong><?= $k['jumlah'] ?></strong> siswa terdaftar</p>
</div>
<div class="d-grid gap-2">
<?php if($isBK): ?>
<a href="guru.riwayat.php?kelas_id=<?= $k['id'] ?>" class="btn btn-primary fw-semibold">📊 Pantau Riwayat</a>
<?php else: ?>
<a href="guru.absensi.php?kelas_id=<?= $k['id'] ?>" class="btn btn-primary fw-semibold">📝 Isi Absensi</a>
<a href="guru.riwayat.php?kelas_id=<?= $k['id'] ?>" class="btn btn-outline-primary fw-semibold">📊 Lihat Riwayat</a>
<?php endif; ?>
</div>
</div>
</div>
<?php endforeach; ?>
</div>

<?php if(!$data): ?>
<div class="alert alert-warning shadow-sm border-0 bg-white text-dark mt-3">
⚠️ Belum ada data kelas yang tersedia.
</div>
<?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>