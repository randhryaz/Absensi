
<?php
require 'config.koneksi.php';

// Pastikan token tab tersedia
$token = tokenAktif();

if (!$token) {
    header("Location: auth.login.php");
    exit;
}

// Validasi login berdasarkan token tab
wajibLogin();

// Ambil role pengguna dari session yang sudah divalidasi
$role = $_SESSION['user']['role'];

// Tentukan dashboard
if ($role === 'admin') {
    $dashboard = 'admin.dashboard.php';
} elseif ($role === 'guru') {
    $dashboard = 'guru.dashboard.php';
} elseif ($role === 'siswa') {
    $dashboard = 'siswa.dashboard.php';
} else {
    http_response_code(403);
    exit("Role pengguna tidak dikenali.");
}

// Teruskan token ke dashboard
header("Location: " . $dashboard . "?tab_token=" . urlencode($token));
exit;
