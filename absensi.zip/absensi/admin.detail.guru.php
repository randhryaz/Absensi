<?php
require 'config.koneksi.php';
wajibRole('admin');

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("
    SELECT id,nbm,nama,username,role
    FROM users
    WHERE id=? AND role='guru'
");
$stmt->execute([$id]);
$guru = $stmt->fetch();

if (!$guru) {
    http_response_code(404);
    exit('Guru tidak ditemukan!');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Detail Guru</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #60a5fa 100%);
        min-height: 100vh;
        color: #1e293b;
    }
    .custom-container {
        max-width: 600px;
    }
    .card {
        border: none;
        border-radius: 14px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        background-color: #ffffff;
    }
    .back-link {
        color: #e2e8f0;
        text-decoration: none;
        font-weight: 500;
        display: inline-block;
        margin-bottom: 15px;
        transition: color 0.2s;
    }
    .back-link:hover {
        color: #ffffff;
        text-decoration: underline;
    }
    .detail-label {
        color: #64748b;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .detail-value {
        font-size: 1.1rem;
        font-weight: 600;
        color: #1e293b;
    }
</style>
</head>
<body>
<div class="container custom-container py-5">
<a href="admin.guru.php" class="back-link">← Kembali</a>

<div class="card p-4 p-md-5">
<div class="text-center mb-4">
<div style="font-size: 60px;" class="mb-2">👨‍🏫</div>
<h4 class="fw-bold text-dark">Detail Akun Guru</h4>
<p class="text-muted small">Informasi lengkap data akun pengajar</p>
</div>
<hr class="text-muted mb-4">

<div class="mb-3">
<div class="detail-label">ID Pengguna</div>
<div class="detail-value">#<?= (int)$guru['id'] ?></div>
</div>

<div class="mb-3">
<div class="detail-label">Nama Lengkap</div>
<div class="detail-value"><?= e($guru['nama']) ?></div>
</div>

<div class="mb-3">
<div class="detail-label">Username</div>
<div class="detail-value"><span class="badge bg-primary px-3 py-2"><?= e($guru['username']) ?></span></div>
</div>

<div class="mb-3">
<div class="detail-label">Role Akses</div>
<div class="detail-value text-capitalize"><span class="badge bg-success px-3 py-2"><?= e($guru['role']) ?></span></div>
</div>

</div>
</div>
</body>
</html>