
<?php
require 'config.koneksi.php';
wajibRole('admin');
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dashboard Admin - SMK MUHAYO</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="style.css" rel="stylesheet">

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    min-height: 100vh;
    background: linear-gradient(135deg, #1e3a8a, #2563eb, #60a5fa);
    font-family: Arial, sans-serif;
    overflow-x: hidden;
}

/* SIDEBAR */
.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 280px;
    height: 100vh;
    background: rgba(255,255,255,0.95);
    box-shadow: 4px 0 20px rgba(0,0,0,0.15);
    z-index: 1000;
    transition: 0.3s ease;
    overflow-y: auto;
}

.sidebar-header {
    height: 90px;
    display: flex;
    align-items: center;
    padding: 20px;
    background: linear-gradient(135deg, #0645a8, #087cf0);
    color: white;
    font-size: 20px;
    font-weight: bold;
}

.sidebar-header span {
    margin-left: 10px;
}

.sidebar-menu {
    padding: 15px;
}

.sidebar-menu a {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 14px 15px;
    margin-bottom: 10px;
    border-radius: 13px;
    color: #0758cf;
    font-weight: 600;
    font-size: 16px;
    text-decoration: none;
    background: white;
    transition: 0.2s;
}

.sidebar-menu a:hover,
.sidebar-menu a.active {
    background: linear-gradient(135deg, #0755ce, #168bff);
    color: white;
    transform: translateX(4px);
}

.menu-icon {
    font-size: 21px;
    width: 25px;
    text-align: center;
}

/* MAIN CONTENT */
.main-content {
    margin-left: 280px;
    min-height: 100vh;
    transition: 0.3s ease;
}

/* TOPBAR */
.topbar {
    height: 75px;
    background: rgba(0, 75, 180, 0.45);
    backdrop-filter: blur(10px);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 30px;
    border-bottom: 1px solid rgba(255,255,255,0.2);
}

.topbar-title {
    color: white;
    font-size: 22px;
    font-weight: bold;
}

.toggle-btn {
    background: transparent;
    border: none;
    color: white;
    font-size: 28px;
    cursor: pointer;
    margin-right: 20px;
}

.logout-btn {
    background: white;
    color: #dc3545;
    border: none;
    padding: 9px 18px;
    border-radius: 8px;
    font-weight: bold;
    text-decoration: none;
}

.logout-btn:hover {
    background: #ffe5e5;
    color: #b91c1c;
}

/* DASHBOARD */
.content-area {
    padding: 40px;
}

.content-area h2 {
    color: white;
    font-weight: bold;
    font-size: 32px;
}

.content-area p {
    color: white;
    font-size: 16px;
}

/* SIDEBAR COLLAPSE DESKTOP */
.sidebar.collapsed {
    width: 0;
    overflow: hidden;
}

.main-content.expanded {
    margin-left: 0;
}

/* MOBILE */
@media (max-width: 768px) {
    .sidebar {
        transform: translateX(-100%);
        width: 280px;
    }

    .sidebar.mobile-open {
        transform: translateX(0);
    }

    .main-content {
        margin-left: 0;
    }

    .content-area {
        padding: 25px 18px;
    }

    .content-area h2 {
        font-size: 25px;
    }

    .topbar {
        padding: 0 15px;
    }

    .topbar-title {
        font-size: 17px;
    }
}

/* OVERLAY MOBILE */
.sidebar-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.4);
    z-index: 999;
}

.sidebar-overlay.show {
    display: block;
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">

    <div class="sidebar-header">
        🎓
        <span>SMK MUHAYO</span>
    </div>

    <div class="sidebar-menu">

        <a href="admin.guru.php">
            <span class="menu-icon">👨‍🏫</span>
            Data Guru
        </a>

        <a href="admin.siswa.php">
            <span class="menu-icon">👨‍🎓</span>
            Data Siswa
        </a>

        <a href="admin.kelas.php">
            <span class="menu-icon">🏫</span>
            Data Kelas
        </a>

        <a href="admin.akun.guru.php">
            <span class="menu-icon">🔑</span>
            Akun Guru
        </a>

        <a href="admin.akun.siswa.php">
            <span class="menu-icon">🔑</span>
            Akun Siswa
        </a>

        <a href="admin.laporan.php">
            <span class="menu-icon">📈</span>
            Laporan Absensi
        </a>

        <a href="admin.setting.bg_guru.php">
            <span class="menu-icon">🖼️</span>
            BG Dashboard Guru
        </a>

        <a href="admin.setting.bg_siswa.php">
            <span class="menu-icon">🖼️</span>
            BG Dashboard Siswa
        </a>

        <a href="admin.setting.bg_login.php">
            <span class="menu-icon">🎨</span>
            BG Halaman Login
        </a>

    </div>
</aside>

<!-- OVERLAY MOBILE -->
<div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>

<!-- MAIN CONTENT -->
<div class="main-content" id="mainContent">

    <!-- TOPBAR -->
    <nav class="topbar">

        <div class="d-flex align-items-center">
            <button class="toggle-btn" onclick="toggleSidebar()">
                ☰
            </button>

            <span class="topbar-title">Dashboard Admin</span>
        </div>

        <a href="auth.logout.php" class="logout-btn">
            Logout
        </a>

    </nav>

    <!-- CONTENT -->
    <main class="content-area">

        <h2>Dashboard Admin</h2>

        <p>
            Selamat datang, Admin. Silakan kelola data dan
            pengaturan sistem absensi di bawah ini.
        </p>

    </main>

</div>

<script>
const sidebar = document.getElementById('sidebar');
const mainContent = document.getElementById('mainContent');
const overlay = document.getElementById('overlay');

function toggleSidebar() {

    if (window.innerWidth <= 768) {

        sidebar.classList.toggle('mobile-open');
        overlay.classList.toggle('show');

    } else {

        sidebar.classList.toggle('collapsed');
        mainContent.classList.toggle('expanded');

    }

}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
