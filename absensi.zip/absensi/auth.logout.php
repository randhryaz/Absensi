
<?php
require 'config.koneksi.php';

$token = tokenAktif();

if ($token !== '') {
    $stmt = $pdo->prepare("
        DELETE FROM user_sessions
        WHERE token_hash = ?
    ");

    $stmt->execute([
        hash('sha256', $token)
    ]);
}

// Hapus session PHP lokal
$_SESSION = [];

if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

session_destroy();

header("Location: auth.login.php");
exit;
