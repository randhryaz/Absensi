<?php
require 'config.koneksi.php';
wajibRole('siswa');

$id = $_SESSION['user']['id'];

// Ambil background khusus dashboard siswa dari database (jika ada)
$bgStyle = "background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #60a5fa 100%);";
try {
    $stmtBg = $pdo->prepare("SELECT value_text FROM settings WHERE key_name = 'bg_siswa_dashboard'");
    $stmtBg->execute();
    $customBgSiswa = $stmtBg->fetchColumn();

    if ($customBgSiswa && file_exists($customBgSiswa)) {
        $bgStyle = "background: url('" . e($customBgSiswa) . "') no-repeat center center fixed; background-size: cover;";
    }
} catch (Throwable $e) {
    // Jika tabel/setting belum ada, gunakan default gradasi
}

$stmt = $pdo->prepare("
SELECT s.*,k.nama_kelas
FROM siswa s JOIN kelas k ON k.id=s.kelas_id
WHERE s.id=?
");
$stmt->execute([$id]);
$siswa = $stmt->fetch();

if (!$siswa) exit("Data siswa tidak ditemukan!");

$stmt = $pdo->prepare("
SELECT
COUNT(*) AS total,
SUM(status='Hadir') AS hadir,
SUM(status='Izin') AS izin,
SUM(status='Sakit') AS sakit,
SUM(status='Alpa') AS alpa
FROM absensi WHERE siswa_id=?
");
$stmt->execute([$id]);
$rekap = $stmt->fetch();

$stmt = $pdo->prepare("
SELECT * FROM absensi
WHERE siswa_id=?
ORDER BY tanggal DESC
LIMIT 100
");
$stmt->execute([$id]);
$data = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashboard Siswa - SMK Muhammadiyah 2 Yogyakarta</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="style.css" rel="stylesheet">
<style>
    body {
        <?= $bgStyle ?>
        min-height: 100vh;
        color: #1e293b;
    }
    .navbar {
        background: linear-gradient(90deg, #1e3a8a, #1d4ed8) !important;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .card {
        border: none;
        border-radius: 14px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
        background-color: #ffffff;
    }
    h3, .welcome-text {
        color: #ffffff;
    }
    .stat-card h2 {
        color: #1d4ed8;
        font-weight: 700;
    }
    .stat-card small {
        color: #64748b;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.75rem;
        letter-spacing: 0.5px;
    }
    .table-container {
        background: #ffffff;
        border-radius: 10px;
        overflow: hidden;
    }
</style>
</head>
<body>
<nav class="navbar navbar-dark px-4 py-3">
<span class="navbar-brand fw-bold">🎓 SMK Muhammadiyah 2 Yogyakarta </span>
<a href="auth.logout.php" class="btn btn-light btn-sm fw-semibold text-danger">Logout</a>
</nav>

<div class="container py-5">
<h3 class="fw-bold mb-1">Halo, <?= e($siswa['nama']) ?> 👋</h3>
<p class="welcome-text mb-4">NIS: <?= e($siswa['nis']) ?> | Kelas: <?= e($siswa['nama_kelas']) ?></p>

<div class="row g-3 mb-4">
<?php foreach([
    'Total'=>$rekap['total'] ?? 0,
    'Hadir'=>$rekap['hadir'] ?? 0,
    'Izin'=>$rekap['izin'] ?? 0,
    'Sakit'=>$rekap['sakit'] ?? 0,
    'Alpa'=>$rekap['alpa'] ?? 0
] as $label=>$jumlah): ?>
<div class="col-6 col-md">
<div class="card stat-card border-0 shadow-sm p-3 text-center">
<small><?= $label ?></small>
<h2 class="mt-1 mb-0"><?= $jumlah ?></h2>
</div>
</div>
<?php endforeach; ?>
</div>

<div class="card p-4 shadow-sm">
<h5 class="text-primary fw-bold mb-3">📋 Riwayat Absensi Saya</h5>
<div class="table-responsive table-container mb-3">
<table class="table table-hover align-middle mb-0">
<thead class="table-light">
<tr>
<th>Tanggal</th>
<th>Status</th>
<th>Keterangan</th>
</tr>
</thead>
<tbody>
<?php foreach($data as $a): ?>
<tr>
<td class="fw-semibold"><?= e($a['tanggal']) ?></td>
<td>
<?php if($a['status'] === 'Hadir'): ?>
<span class="badge bg-success">Hadir</span>
<?php elseif($a['status'] === 'Izin'): ?>
<span class="badge bg-info text-dark">Izin</span>
<?php elseif($a['status'] === 'Sakit'): ?>
<span class="badge bg-warning text-dark">Sakit</span>
<?php else: ?>
<span class="badge bg-danger"><?= e($a['status']) ?></span>
<?php endif; ?>
</td>
<td><?= e($a['keterangan'] ?: '-') ?></td>
</tr>
<?php endforeach; ?>
<?php if(!$data): ?>
<tr><td colspan="3" class="text-center text-muted py-3">Belum ada riwayat absensi.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
<p class="text-muted small mb-0">Menampilkan hingga 100 riwayat absensi terakhir.</p>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>