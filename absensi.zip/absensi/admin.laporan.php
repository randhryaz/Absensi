
<?php
require 'config.koneksi.php';
wajibRole('admin');

// Ambil daftar kelas
$kelasList = $pdo->query("
    SELECT
        k.id,
        k.nama_kelas,
        u.nama AS nama_guru
    FROM kelas k
    LEFT JOIN users u ON u.id = k.guru_id
    ORDER BY k.nama_kelas ASC
")->fetchAll(PDO::FETCH_ASSOC);

// Filter
$kelasId = isset($_GET['kelas_id']) ? (int)$_GET['kelas_id'] : 0;
$mode = $_GET['mode'] ?? 'harian';

if (!in_array($mode, ['harian', 'mingguan', 'bulanan', 'semester'], true)) {
    $mode = 'harian';
}

$tanggal = $_GET['tanggal'] ?? date('Y-m-d');
$bulan = $_GET['bulan'] ?? date('Y-m');
$semester = $_GET['semester'] ?? 'ganjil';
$tahun = isset($_GET['tahun']) ? (int)$_GET['tahun'] : (int)date('Y');

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) {
    $tanggal = date('Y-m-d');
}

if (!preg_match('/^\d{4}-\d{2}$/', $bulan)) {
    $bulan = date('Y-m');
}

if (!in_array($semester, ['ganjil', 'genap'], true)) {
    $semester = 'ganjil';
}

if ($tahun < 2000 || $tahun > 2100) {
    $tahun = (int)date('Y');
}

// Tentukan periode laporan
switch ($mode) {
    case 'harian':
        $tanggalAwal = $tanggal;
        $tanggalAkhir = $tanggal;
        $judulPeriode = date('d-m-Y', strtotime($tanggal));
        break;

    case 'mingguan':
        $waktu = strtotime($tanggal);
        $hari = (int)date('N', $waktu);

        $tanggalAwal = date('Y-m-d', strtotime('-' . ($hari - 1) . ' days', $waktu));
        $tanggalAkhir = date('Y-m-d', strtotime('+' . (7 - $hari) . ' days', $waktu));

        $judulPeriode = date('d-m-Y', strtotime($tanggalAwal)) .
            ' sampai ' . date('d-m-Y', strtotime($tanggalAkhir));
        break;

    case 'bulanan':
        $tanggalAwal = $bulan . '-01';
        $tanggalAkhir = date('Y-m-t', strtotime($tanggalAwal));

        $judulPeriode = date('F Y', strtotime($tanggalAwal));
        break;

    case 'semester':
        if ($semester === 'ganjil') {
            $tanggalAwal = $tahun . '-07-01';
            $tanggalAkhir = $tahun . '-12-31';
            $judulPeriode = 'Semester Ganjil ' . $tahun . '/' . ($tahun + 1);
        } else {
            $tanggalAwal = ($tahun + 1) . '-01-01';
            $tanggalAkhir = ($tahun + 1) . '-06-30';
            $judulPeriode = 'Semester Genap ' . $tahun . '/' . ($tahun + 1);
        }
        break;
}

// Informasi kelas dan guru
$kelasTerpilih = null;
foreach ($kelasList as $kelas) {
    if ((int)$kelas['id'] === $kelasId) {
        $kelasTerpilih = $kelas;
        break;
    }
}

// Ambil seluruh siswa dan rekap absensinya
$dataSiswa = [];

if ($kelasTerpilih) {
    $sql = "
        SELECT
            s.id,
            s.nis,
            s.nama,

            COUNT(a.id) AS total_absensi,

            SUM(CASE WHEN a.status = 'Hadir' THEN 1 ELSE 0 END) AS hadir,
            SUM(CASE WHEN a.status = 'Izin' THEN 1 ELSE 0 END) AS izin,
            SUM(CASE WHEN a.status = 'Sakit' THEN 1 ELSE 0 END) AS sakit,
            SUM(CASE WHEN a.status = 'Alpa' THEN 1 ELSE 0 END) AS alpa

        FROM siswa s

        LEFT JOIN absensi a
            ON a.siswa_id = s.id
            AND a.tanggal BETWEEN ? AND ?

        WHERE s.kelas_id = ?

        GROUP BY s.id, s.nis, s.nama

        ORDER BY s.nama ASC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$tanggalAwal, $tanggalAkhir, $kelasId]);
    $dataSiswa = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Total seluruh kelas
$total = [
    'hadir' => 0,
    'izin' => 0,
    'sakit' => 0,
    'alpa' => 0
];

foreach ($dataSiswa as $siswa) {
    $total['hadir'] += (int)$siswa['hadir'];
    $total['izin'] += (int)$siswa['izin'];
    $total['sakit'] += (int)$siswa['sakit'];
    $total['alpa'] += (int)$siswa['alpa'];
}

$totalSemua = array_sum($total);

// Export CSV
if (
    isset($_GET['export']) &&
    $_GET['export'] === 'csv' &&
    $kelasTerpilih
) {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="laporan_absensi.csv"');

    $output = fopen('php://output', 'w');
    fwrite($output, "\xEF\xBB\xBF");

    fputcsv($output, [
        'NIS',
        'Nama Siswa',
        'Kelas',
        'Nama Guru',
        'Hadir',
        'Izin',
        'Sakit',
        'Alpa',
        'Total Absensi'
    ], ';');

    foreach ($dataSiswa as $siswa) {
        fputcsv($output, [
            $siswa['nis'],
            $siswa['nama'],
            $kelasTerpilih['nama_kelas'],
            $kelasTerpilih['nama_guru'] ?? '-',
            $siswa['hadir'],
            $siswa['izin'],
            $siswa['sakit'],
            $siswa['alpa'],
            $siswa['total_absensi']
        ], ';');
    }

    fclose($output);
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laporan Absensi - SMK MUHAYO</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #1e3a8a, #2563eb, #60a5fa);
            min-height: 100vh;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 1200px;
        }

        .page-title {
            color: white;
            font-weight: bold;
        }

        .card {
            border: none;
            border-radius: 14px;
            box-shadow: 0 8px 25px rgba(0,0,0,.12);
        }

        .stat-card {
            padding: 20px;
            border-radius: 12px;
            color: white;
        }

        .stat-card h3 {
            font-weight: bold;
            margin-bottom: 0;
        }

        .table th {
            white-space: nowrap;
        }

        @media print {
            body {
                background: white !important;
            }

            .no-print {
                display: none !important;
            }

            .card {
                box-shadow: none;
                border: 1px solid #ddd;
            }

            .page-title {
                color: black;
            }

            .stat-card {
                color: black !important;
                background: white !important;
                border: 1px solid #ddd;
            }
        }
    </style>
</head>

<body>

<div class="container py-5">

    <div class="no-print mb-3">
        <a href="admin.dashboard.php" class="text-white text-decoration-none back-link" style="display:inline-block;background:#dc3545;color:#fff;text-decoration:none;padding:7px 13px;border-radius:6px;width:fit-content;margin-bottom:15px;font-weight:500">← Kembali</a>
    </div>

    <h3 class="page-title mb-1">📊 Laporan Absensi Siswa</h3>

    <p class="text-white mb-4">
        SMK Muhammadiyah 2 Yogyakarta
    </p>

    <!-- FILTER -->
    <div class="card p-4 mb-4 no-print">

        <form method="GET" class="row g-3">

            <div class="col-md-4">
                <label class="form-label fw-semibold">Pilih Kelas</label>

                <select name="kelas_id" class="form-select" required>
                    <option value="">-- Pilih Kelas Terlebih Dahulu --</option>

                    <?php foreach ($kelasList as $kelas): ?>
                        <option
                            value="<?= (int)$kelas['id'] ?>"
                            <?= $kelasId === (int)$kelas['id'] ? 'selected' : '' ?>
                        >
                            <?= e($kelas['nama_kelas']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-3">
                <label class="form-label fw-semibold">Jenis Laporan</label>

                <select name="mode" id="mode" class="form-select">
                    <option value="harian" <?= $mode === 'harian' ? 'selected' : '' ?>>
                        Per Hari
                    </option>

                    <option value="mingguan" <?= $mode === 'mingguan' ? 'selected' : '' ?>>
                        Per Minggu
                    </option>

                    <option value="bulanan" <?= $mode === 'bulanan' ? 'selected' : '' ?>>
                        Per Bulan
                    </option>

                    <option value="semester" <?= $mode === 'semester' ? 'selected' : '' ?>>
                        Per Semester
                    </option>
                </select>
            </div>

            <div class="col-md-3" id="filterTanggal">
                <label class="form-label fw-semibold">Pilih Tanggal</label>
                <input type="date" name="tanggal" class="form-control"
                       value="<?= e($tanggal) ?>">
            </div>

            <div class="col-md-3" id="filterBulan">
                <label class="form-label fw-semibold">Pilih Bulan</label>
                <input type="month" name="bulan" class="form-control"
                       value="<?= e($bulan) ?>">
            </div>

            <div class="col-md-2" id="filterSemester">
                <label class="form-label fw-semibold">Semester</label>

                <select name="semester" class="form-select">
                    <option value="ganjil" <?= $semester === 'ganjil' ? 'selected' : '' ?>>
                        Ganjil
                    </option>

                    <option value="genap" <?= $semester === 'genap' ? 'selected' : '' ?>>
                        Genap
                    </option>
                </select>
            </div>

            <div class="col-md-2" id="filterTahun">
                <label class="form-label fw-semibold">Tahun Awal</label>
                <select name="tahun" class="form-select">
                    <?php for ($y = (int)date('Y') - 5; $y <= (int)date('Y') + 1; $y++): ?>
                        <option value="<?= $y ?>" <?= $tahun === $y ? 'selected' : '' ?>>
                            <?= $y ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">
                    Tampilkan
                </button>
            </div>

        </form>
    </div>

    <?php if (!$kelasTerpilih): ?>

        <div class="card p-5 text-center">
            <h4 class="fw-bold">Silakan Pilih Kelas</h4>
            <p class="text-muted mb-0">
                Pilih kelas terlebih dahulu untuk melihat seluruh data absensi siswa.
            </p>
        </div>

    <?php else: ?>

        <!-- INFORMASI KELAS -->
        <div class="card p-4 mb-4 text-center">

            <h4 class="fw-bold mb-2">LAPORAN ABSENSI SISWA</h4>

            <h5 class="text-primary fw-bold">
                Kelas <?= e($kelasTerpilih['nama_kelas']) ?>
            </h5>

            <p class="mb-1">
                Nama Guru:
                <strong><?= e($kelasTerpilih['nama_guru'] ?? 'Belum ditentukan') ?></strong>
            </p>

            <p class="mb-0">
                Periode:
                <strong><?= e($judulPeriode) ?></strong>
            </p>

        </div>

        <!-- TOTAL -->
        <div class="row g-3 mb-4">

            <div class="col-6 col-md-3">
                <div class="stat-card bg-success">
                    Hadir
                    <h3><?= number_format($total['hadir']) ?></h3>
                </div>
            </div>

            <div class="col-6 col-md-3">
                <div class="stat-card bg-info">
                    Izin
                    <h3><?= number_format($total['izin']) ?></h3>
                </div>
            </div>

            <div class="col-6 col-md-3">
                <div class="stat-card bg-warning text-dark">
                    Sakit
                    <h3><?= number_format($total['sakit']) ?></h3>
                </div>
            </div>

            <div class="col-6 col-md-3">
                <div class="stat-card bg-danger">
                    Alpa
                    <h3><?= number_format($total['alpa']) ?></h3>
                </div>
            </div>

        </div>

        <!-- TABEL SISWA -->
        <div class="card p-4 mb-4">

            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold mb-0">DAFTAR ABSENSI SELURUH SISWA</h5>

                <span class="badge bg-primary">
                    <?= count($dataSiswa) ?> Siswa
                </span>
            </div>

            <div class="table-responsive">

                <table class="table table-bordered table-hover align-middle">

                    <thead class="table-primary">
                        <tr>
                            <th>No</th>
                            <th>NIS</th>
                            <th>Nama Siswa</th>
                            <th>Hadir</th>
                            <th>Izin</th>
                            <th>Sakit</th>
                            <th>Alpa</th>
                            <th>Total Absensi</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php if (!$dataSiswa): ?>

                            <tr>
                                <td colspan="8" class="text-center text-muted">
                                    Belum ada siswa di kelas ini.
                                </td>
                            </tr>

                        <?php else: ?>

                            <?php $no = 1; ?>

                            <?php foreach ($dataSiswa as $siswa): ?>

                                <tr>
                                    <td><?= $no++ ?></td>

                                    <td><?= e($siswa['nis']) ?></td>

                                    <td class="fw-semibold">
                                        <?= e($siswa['nama']) ?>
                                    </td>

                                    <td class="text-success fw-bold">
                                        <?= (int)$siswa['hadir'] ?>
                                    </td>

                                    <td><?= (int)$siswa['izin'] ?></td>

                                    <td><?= (int)$siswa['sakit'] ?></td>

                                    <td class="text-danger fw-bold">
                                        <?= (int)$siswa['alpa'] ?>
                                    </td>

                                    <td class="fw-bold">
                                        <?= (int)$siswa['total_absensi'] ?>
                                    </td>
                                </tr>

                            <?php endforeach; ?>

                        <?php endif; ?>

                    </tbody>

                    <tfoot class="table-light fw-bold">
                        <tr>
                            <td colspan="3" class="text-end">TOTAL</td>
                            <td><?= $total['hadir'] ?></td>
                            <td><?= $total['izin'] ?></td>
                            <td><?= $total['sakit'] ?></td>
                            <td><?= $total['alpa'] ?></td>
                            <td><?= $totalSemua ?></td>
                        </tr>
                    </tfoot>

                </table>

            </div>
        </div>

        <!-- TOMBOL -->
        <div class="d-flex flex-wrap gap-2 mb-4 no-print">

            <button onclick="window.print()" class="btn btn-success fw-semibold">
                🖨️ Cetak / Simpan PDF
            </button>

            <a href="?kelas_id=<?= $kelasId ?>&mode=<?= e($mode) ?>&tanggal=<?= e($tanggal) ?>&bulan=<?= e($bulan) ?>&semester=<?= e($semester) ?>&tahun=<?= $tahun ?>&export=csv"
               class="btn btn-light fw-semibold">
                📥 Download Excel (CSV)
            </a>

            <a href="admin.laporan.php" class="btn btn-outline-light">
                Reset
            </a>

        </div>

    <?php endif; ?>

</div>

<script>
function aturFilter() {
    const mode = document.getElementById('mode').value;

    document.getElementById('filterTanggal').style.display =
        (mode === 'harian' || mode === 'mingguan') ? 'block' : 'none';

    document.getElementById('filterBulan').style.display =
        mode === 'bulanan' ? 'block' : 'none';

    document.getElementById('filterSemester').style.display =
        mode === 'semester' ? 'block' : 'none';

    document.getElementById('filterTahun').style.display =
        mode === 'semester' ? 'block' : 'none';
}

document.getElementById('mode').addEventListener('change', aturFilter);
aturFilter();
</script>

</body>
</html>
