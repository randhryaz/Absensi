
<?php
define('KUNCI_PASSWORD', 'GantiDenganKunciRahasia32Karakter!');
