<?php
require 'config.koneksi.php';
require_once 'fungsi.akun.guru.php';
wajibRole('admin');

$pesan = '';
$jenis = 'info';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cekCsrf();

    if (isset($_FILES['file_excel']) && $_FILES['file_excel']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['file_excel']['tmp_name'];
        $fileName = $_FILES['file_excel']['name'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if ($fileExtension !== 'csv') {
            $pesan = "Format file harus berupa CSV (.csv)! Silakan export file Excel Anda ke format CSV terlebih dahulu.";
            $jenis = 'danger';
        } else {
            try {
                $handle = fopen($fileTmpPath, 'r');
                if ($handle === false) {
                    throw new Exception("Gagal membaca file.");
                }

                $pdo->beginTransaction();
                $berhasil = 0;
                $gagal = 0;

                // Format CSV: NBM, Nama (baris pertama adalah header)
                fgetcsv($handle);
                while (($row = fgetcsv($handle, 0, ',')) !== false) {
                    $nbm = trim($row[0] ?? '');
                    $nama = trim($row[1] ?? '');
                    if ($nbm === '' || $nama === '') { $gagal++; continue; }
                    try {
                        buatAkunGuruOtomatis($nbm, $nama, $pdo);
                        $berhasil++;
                    } catch (PDOException $e) {
                        $gagal++;
                    }
                }

                fclose($handle);
                $pdo->commit();

                $pesan = "Import selesai! Berhasil menambahkan $berhasil guru, gagal/duplikat: $gagal.";
                $jenis = 'success';

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $pesan = "Terjadi kesalahan: " . $e->getMessage();
                $jenis = 'danger';
            }
        }
    } else {
        $pesan = "Silakan pilih file CSV terlebih dahulu!";
        $jenis = 'danger';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Import Guru - SMK Muhammadiyah 2 Yogyakarta</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #60a5fa 100%);
        min-height: 100vh;
        color: #1e293b;
    }
    .custom-container {
        max-width: 600px;
    }
    .card {
        border: none;
        border-radius: 14px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        background-color: #ffffff;
    }
    .back-link {
        background: #dc3545; color: #fff; padding: 7px 13px; border-radius: 6px; width: fit-content;
        text-decoration: none;
        font-weight: 500;
        display: inline-block;
        margin-bottom: 15px;
        transition: color 0.2s;
    }
    .back-link:hover {
        background: #bb2d3b; color: #ffffff;
        text-decoration: underline;
    }
    h3 {
        color: #ffffff;
        font-weight: 700;
    }
</style>
</head>
<body>
<div class="container custom-container py-5">
<a href="admin.guru.php" class="back-link">← Kembali ke Data Guru</a>
<h3 class="my-3">Import Data Guru (CSV)</h3>

<?php if ($pesan): ?>
<div class="alert alert-<?= e($jenis) ?> shadow-sm"><?= e($pesan) ?></div>
<?php endif; ?>

<div class="card p-4 shadow-sm">
<h5 class="text-primary fw-bold mb-3">📁 Upload File CSV Guru</h5>
<p class="text-muted small">
Pastikan file Excel Anda disimpan dalam format <strong>CSV (Comma Delimited)</strong> dengan urutan kolom:
<br><code>NBM | Nama</code> (Baris pertama dianggap sebagai header/judul).
<br>Username otomatis menggunakan NBM dan password acak 12 karakter dibuat untuk setiap guru.
</p>

<form method="POST" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">

<div class="mb-3">
<label class="form-label fw-semibold">Pilih File CSV</label>
<input type="file" name="file_excel" class="form-control" accept=".csv" required>
</div>

<button type="submit" class="btn btn-success px-4 fw-semibold">🚀 Proses Import</button>
</form>
</div>
</div>
</body>
</html>