
<?php
require 'config.koneksi.php';
wajibRole('guru');

$tabToken = tokenAktif();
$id = (int)($_GET['kelas_id'] ?? 0);

$user = $_SESSION['user'] ?? [];
$userRole = $user['role'] ?? '';
$userName = $user['nama'] ?? '';

$isBK = ($userRole === 'bk' || stripos($userName, 'bk') !== false);

// Background
$bgStyle = "background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #60a5fa 100%);";

try {
    $stmtBg = $pdo->prepare("SELECT value_text FROM settings WHERE key_name = 'bg_guru_dashboard'");
    $stmtBg->execute();
    $customBgGuru = $stmtBg->fetchColumn();

    if ($customBgGuru && file_exists($customBgGuru)) {
        $bgStyle = "background: url('" . e($customBgGuru) . "') no-repeat center center fixed; background-size: cover;";
    }
} catch (Throwable $e) {
}

// Hak akses kelas
if ($isBK) {
    $stmt = $pdo->prepare("SELECT * FROM kelas WHERE id = ?");
    $stmt->execute([$id]);
} else {
    $stmt = $pdo->prepare("SELECT * FROM kelas WHERE id = ? AND guru_id = ?");
    $stmt->execute([$id, $user['id'] ?? 0]);
}

$kelas = $stmt->fetch();

if (!$kelas) {
    exit("Akses ditolak atau kelas tidak ditemukan!");
}

// Filter
$jenisFilter = $_GET['jenis'] ?? 'hari';
$tanggal = $_GET['tanggal'] ?? '';
$bulan = $_GET['bulan'] ?? '';
$tahun = $_GET['tahun'] ?? date('Y');
$semester = $_GET['semester'] ?? 'ganjil';

$data = [];
$sudahFilter = false;
$pesanError = '';

$tanggalAwal = '';
$tanggalAkhir = '';

try {

    if (isset($_GET['filter']) || isset($_GET['export'])) {

        // Tentukan periode
        switch ($jenisFilter) {

            case 'hari':

                $dt = DateTime::createFromFormat('!Y-m-d', $tanggal);

                if (!$dt || $dt->format('Y-m-d') !== $tanggal) {
                    throw new Exception("Pilih tanggal yang valid.");
                }

                $tanggalAwal = $tanggal;
                $tanggalAkhir = $tanggal;
                break;

            case 'minggu':

                $dt = DateTime::createFromFormat('!Y-m-d', $tanggal);

                if (!$dt || $dt->format('Y-m-d') !== $tanggal) {
                    throw new Exception("Pilih tanggal untuk menentukan minggu.");
                }

                $tanggalAwal = (clone $dt)->modify('monday this week')->format('Y-m-d');
                $tanggalAkhir = (clone $dt)->modify('sunday this week')->format('Y-m-d');
                break;

            case 'bulan':

                $dt = DateTime::createFromFormat('!Y-m', $bulan);

                if (!$dt || $dt->format('Y-m') !== $bulan) {
                    throw new Exception("Pilih bulan yang valid.");
                }

                $tanggalAwal = $dt->format('Y-m-01');
                $tanggalAkhir = $dt->format('Y-m-t');
                break;

            case 'semester':

                if (
                    !preg_match('/^\d{4}$/', (string)$tahun) ||
                    (int)$tahun < 2000 ||
                    (int)$tahun > 2100 ||
                    !in_array($semester, ['ganjil', 'genap'], true)
                ) {
                    throw new Exception("Tahun atau semester tidak valid.");
                }

                if ($semester === 'ganjil') {
                    $tanggalAwal = $tahun . '-07-01';
                    $tanggalAkhir = $tahun . '-12-31';
                } else {
                    $tanggalAwal = $tahun . '-01-01';
                    $tanggalAkhir = $tahun . '-06-30';
                }

                break;

            default:
                throw new Exception("Jenis laporan tidak valid.");
        }

        // PER HARI: tampilkan detail
        if ($jenisFilter === 'hari') {

            $query = "
                SELECT
                    s.nama,
                    s.nis,
                    a.tanggal,
                    a.status,
                    a.keterangan
                FROM absensi a
                JOIN siswa s ON s.id = a.siswa_id
                WHERE s.kelas_id = ?
                AND a.tanggal BETWEEN ? AND ?
                ORDER BY s.nama ASC
            ";

            $stmt = $pdo->prepare($query);
            $stmt->execute([$id, $tanggalAwal, $tanggalAkhir]);

            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        } else {

            // MINGGU, BULAN, SEMESTER: rekap total
            // Setiap siswa hanya muncul satu kali.

            $query = "
                SELECT
                    s.id,
                    s.nama,
                    s.nis,

                    COALESCE(SUM(
                        CASE WHEN a.status = 'Hadir'
                        THEN 1 ELSE 0 END
                    ), 0) AS total_hadir,

                    COALESCE(SUM(
                        CASE WHEN a.status = 'Izin'
                        THEN 1 ELSE 0 END
                    ), 0) AS total_izin,

                    COALESCE(SUM(
                        CASE WHEN a.status = 'Sakit'
                        THEN 1 ELSE 0 END
                    ), 0) AS total_sakit,

                    COALESCE(SUM(
                        CASE WHEN a.status IN ('Alpa', 'Alpha')
                        THEN 1 ELSE 0 END
                    ), 0) AS total_alpa

                FROM siswa s

                LEFT JOIN absensi a
                    ON a.siswa_id = s.id
                    AND a.tanggal BETWEEN ? AND ?

                WHERE s.kelas_id = ?

                GROUP BY s.id, s.nama, s.nis

                ORDER BY s.nama ASC
            ";

            $stmt = $pdo->prepare($query);
            $stmt->execute([$tanggalAwal, $tanggalAkhir, $id]);

            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        $sudahFilter = true;

        // EKSPOR CSV
        if (isset($_GET['export'])) {

            $namaFile = 'laporan_absensi_' . $jenisFilter . '_' . $id . '.csv';

            header('Content-Type: text/csv; charset=UTF-8');
            header('Content-Disposition: attachment; filename="' . $namaFile . '"');

            echo "\xEF\xBB\xBF";

            $output = fopen('php://output', 'w');

            if ($jenisFilter === 'hari') {

                fputcsv($output, [
                    'Nama Siswa',
                    'NIS',
                    'Tanggal',
                    'Status',
                    'Keterangan'
                ], ';');

                foreach ($data as $row) {
                    $baris = [
                        $row['nama'],
                        $row['nis'],
                        $row['tanggal'],
                        $row['status'],
                        $row['keterangan'] ?: '-'
                    ];

                    foreach ($baris as &$nilai) {
                        $nilai = (string)$nilai;
                        if (preg_match('/^[\s]*[=+\-@]/', $nilai)) {
                            $nilai = "'" . $nilai;
                        }
                    }
                    unset($nilai);

                    fputcsv($output, $baris, ';');
                }

            } else {

                fputcsv($output, [
                    'Nama Siswa',
                    'NIS',
                    'Total Hadir',
                    'Total Izin',
                    'Total Sakit',
                    'Total Alpa',
                    'Total Absensi'
                ], ';');

                foreach ($data as $row) {

                    $total =
                        (int)$row['total_hadir'] +
                        (int)$row['total_izin'] +
                        (int)$row['total_sakit'] +
                        (int)$row['total_alpa'];

                    fputcsv($output, [
                        $row['nama'],
                        $row['nis'],
                        $row['total_hadir'],
                        $row['total_izin'],
                        $row['total_sakit'],
                        $row['total_alpa'],
                        $total
                    ], ';');
                }
            }

            fclose($output);
            exit;
        }
    }

} catch (Throwable $e) {
    $pesanError = $e->getMessage();
}

// Hitung total keseluruhan
$jumlahHadir = 0;
$jumlahIzin = 0;
$jumlahSakit = 0;
$jumlahAlpa = 0;

if ($jenisFilter !== 'hari') {
    foreach ($data as $row) {
        $jumlahHadir += (int)$row['total_hadir'];
        $jumlahIzin += (int)$row['total_izin'];
        $jumlahSakit += (int)$row['total_sakit'];
        $jumlahAlpa += (int)$row['total_alpa'];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Riwayat Absensi - SMK MUHAYO</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="style.css" rel="stylesheet">

<style>
body {
    <?= $bgStyle ?>
    min-height: 100vh;
    color: #1e293b;
}

.custom-container {
    max-width: 1000px;
}

.card {
    border: none;
    border-radius: 14px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
    background-color: #ffffff;
}

.back-link {
    display: inline-block;
    background: #dc3545;
    color: white;
    text-decoration: none;
    font-weight: 600;
    padding: 9px 25px;
    border-radius: 7px;
    margin-bottom: 15px;
    transition: 0.2s;
}

.back-link:hover {
    background: #bb2d3b;
    color: white;
}

h3 {
    color: #ffffff;
    font-weight: 700;
}

.table-container {
    background: #ffffff;
    border-radius: 10px;
    overflow: hidden;
}

.filter-section {
    display: none;
}

.summary-card {
    border-radius: 10px;
    padding: 15px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    height: 100%;
}

.summary-number {
    font-size: 25px;
    font-weight: 700;
}

.summary-label {
    font-size: 13px;
    color: #64748b;
}

</style>
</head>

<body>

<div class="container custom-container py-5">

    <a href="guru.dashboard.php?tab_token=<?= e($tabToken) ?>" class="back-link">
        Kembali
    </a>

    <h3 class="my-3">
        Riwayat Absensi: <?= e($kelas['nama_kelas']) ?>
    </h3>

    <!-- FILTER -->
    <div class="card p-4 shadow-sm mb-4">

        <h5 class="text-primary fw-bold mb-3">
            🔍 Filter Laporan Absensi
        </h5>

        <form method="GET" class="row g-3 align-items-end">

            <input type="hidden" name="kelas_id" value="<?= $id ?>">
            <input type="hidden" name="tab_token" value="<?= e($tabToken) ?>">

            <div class="col-md-4">
                <label class="form-label fw-semibold">Jenis Laporan</label>

                <select name="jenis" id="jenis" class="form-select">
                    <option value="hari" <?= $jenisFilter === 'hari' ? 'selected' : '' ?>>Per Hari</option>
                    <option value="minggu" <?= $jenisFilter === 'minggu' ? 'selected' : '' ?>>Per Minggu</option>
                    <option value="bulan" <?= $jenisFilter === 'bulan' ? 'selected' : '' ?>>Per Bulan</option>
                    <option value="semester" <?= $jenisFilter === 'semester' ? 'selected' : '' ?>>Per Semester</option>
                </select>
            </div>

            <div class="col-md-5 filter-section" id="filter-hari">
                <label class="form-label fw-semibold">Pilih Tanggal</label>
                <input type="date" name="tanggal" class="form-control"
                    value="<?= e($tanggal) ?>">
            </div>

            <div class="col-md-5 filter-section" id="filter-minggu">
                <label class="form-label fw-semibold">Pilih Tanggal dalam Minggu</label>
                <input type="date" name="tanggal" class="form-control"
                    value="<?= e($tanggal) ?>">
            </div>

            <div class="col-md-5 filter-section" id="filter-bulan">
                <label class="form-label fw-semibold">Pilih Bulan</label>
                <input type="month" name="bulan" class="form-control"
                    value="<?= e($bulan) ?>">
            </div>

            <div class="col-md-5 filter-section" id="filter-semester">
                <label class="form-label fw-semibold">Pilih Semester dan Tahun</label>

                <div class="input-group">
                    <select name="semester" class="form-select">
                        <option value="ganjil" <?= $semester === 'ganjil' ? 'selected' : '' ?>>Ganjil</option>
                        <option value="genap" <?= $semester === 'genap' ? 'selected' : '' ?>>Genap</option>
                    </select>

                    <input type="number" name="tahun" class="form-control"
                        min="2000" max="2100" value="<?= e($tahun) ?>">
                </div>
            </div>

            <div class="col-12 d-flex gap-2 flex-wrap">

                <button type="submit" name="filter" value="1"
                    class="btn btn-primary fw-semibold">
                    Tampilkan Data
                </button>

                <button type="submit" name="export" value="csv"
                    class="btn btn-success fw-semibold">
                    📥 Ekspor Excel / CSV
                </button>

                <button type="button"
                    onclick="window.print()"
                    class="btn btn-danger fw-semibold">
                    📄 Cetak / Simpan PDF
                </button>
                <a href="guru.riwayat.php?kelas_id=<?= $id ?>&tab_token=<?= e($tabToken) ?>"
                    class="btn btn-outline-secondary fw-semibold">
                    Reset
                </a>

            </div>

        </form>
    </div>

    <!-- HASIL LAPORAN -->
    <div class="card p-4 shadow-sm">

        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">

            <h5 class="text-primary fw-bold mb-0">
                📊 <?= $jenisFilter === 'hari' ? 'Detail Kehadiran' : 'Rekap Kehadiran Siswa' ?>
            </h5>

            <?php if ($sudahFilter): ?>
                <span class="badge bg-info text-dark">
                    <?= date('d-m-Y', strtotime($tanggalAwal)) ?>
                    s/d
                    <?= date('d-m-Y', strtotime($tanggalAkhir)) ?>
                </span>
            <?php endif; ?>

        </div>

        <?php if ($pesanError): ?>

            <div class="alert alert-warning">
                <?= e($pesanError) ?>
            </div>

        <?php endif; ?>

        <?php if (!$sudahFilter): ?>

            <div class="text-center text-muted py-4">
                Silakan pilih jenis laporan dan periode terlebih dahulu.
            </div>

        <?php elseif ($jenisFilter !== 'hari'): ?>

            <!-- TOTAL KESELURUHAN -->
            <div class="row g-3 mb-4">

                <div class="col-6 col-md-3">
                    <div class="summary-card">
                        <div class="summary-label">Total Hadir</div>
                        <div class="summary-number text-success"><?= $jumlahHadir ?></div>
                    </div>
                </div>

                <div class="col-6 col-md-3">
                    <div class="summary-card">
                        <div class="summary-label">Total Izin</div>
                        <div class="summary-number text-info"><?= $jumlahIzin ?></div>
                    </div>
                </div>

                <div class="col-6 col-md-3">
                    <div class="summary-card">
                        <div class="summary-label">Total Sakit</div>
                        <div class="summary-number text-warning"><?= $jumlahSakit ?></div>
                    </div>
                </div>

                <div class="col-6 col-md-3">
                    <div class="summary-card">
                        <div class="summary-label">Total Alpa</div>
                        <div class="summary-number text-danger"><?= $jumlahAlpa ?></div>
                    </div>
                </div>

            </div>

        <?php endif; ?>

        <div class="table-responsive table-container mb-3">

            <table class="table table-hover align-middle mb-0">

                <thead class="table-light">

                <?php if ($jenisFilter === 'hari'): ?>

                    <tr>
                        <th>Nama Siswa</th>
                        <th>NIS</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                        <th>Keterangan</th>
                    </tr>

                <?php else: ?>

                    <tr>
                        <th>Nama Siswa</th>
                        <th>NIS</th>
                        <th class="text-center">Hadir</th>
                        <th class="text-center">Izin</th>
                        <th class="text-center">Sakit</th>
                        <th class="text-center">Alpa</th>
                        <th class="text-center">Total</th>
                    </tr>

                <?php endif; ?>

                </thead>

                <tbody>

                <?php if ($sudahFilter && empty($data)): ?>

                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">
                            Tidak ada data absensi pada periode tersebut.
                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($data as $s): ?>

                        <?php if ($jenisFilter === 'hari'): ?>

                            <tr>
                                <td class="fw-semibold"><?= e($s['nama']) ?></td>
                                <td><?= e($s['nis']) ?></td>
                                <td><?= date('d-m-Y', strtotime($s['tanggal'])) ?></td>
                                <td>
                                    <?php if ($s['status'] === 'Hadir'): ?>
                                        <span class="badge bg-success">Hadir</span>
                                    <?php elseif ($s['status'] === 'Izin'): ?>
                                        <span class="badge bg-info text-dark">Izin</span>
                                    <?php elseif ($s['status'] === 'Sakit'): ?>
                                        <span class="badge bg-warning text-dark">Sakit</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger"><?= e($s['status']) ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?= e($s['keterangan'] ?: '-') ?></td>
                            </tr>

                        <?php else: ?>

                            <?php
                            $totalSiswa =
                                (int)$s['total_hadir'] +
                                (int)$s['total_izin'] +
                                (int)$s['total_sakit'] +
                                (int)$s['total_alpa'];
                            ?>

                            <tr>
                                <td class="fw-semibold"><?= e($s['nama']) ?></td>
                                <td><?= e($s['nis']) ?></td>
                                <td class="text-center text-success fw-semibold"><?= (int)$s['total_hadir'] ?></td>
                                <td class="text-center text-info fw-semibold"><?= (int)$s['total_izin'] ?></td>
                                <td class="text-center text-warning fw-semibold"><?= (int)$s['total_sakit'] ?></td>
                                <td class="text-center text-danger fw-semibold"><?= (int)$s['total_alpa'] ?></td>
                                <td class="text-center fw-bold"><?= $totalSiswa ?></td>
                            </tr>

                        <?php endif; ?>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>
            </table>

        </div>

        <?php if ($sudahFilter): ?>
            <p class="text-muted small mb-0">
                <strong>Total siswa:</strong> <?= count($data) ?>
                <?php if ($jenisFilter === 'hari'): ?>
                    <br>
                    <strong>Total data absensi:</strong> <?= count($data) ?>
                <?php endif; ?>
            </p>
        <?php endif; ?>

    </div>

</div>

<script>
const jenis = document.getElementById('jenis');

function aturFilter() {

    document.querySelectorAll('.filter-section').forEach(el => {

        el.style.display = 'none';

        el.querySelectorAll('input, select').forEach(input => {
            input.disabled = true;
        });

    });

    const aktif = document.getElementById('filter-' + jenis.value);

    if (aktif) {

        aktif.style.display = 'block';

        aktif.querySelectorAll('input, select').forEach(input => {
            input.disabled = false;
        });

    }
}

jenis.addEventListener('change', aturFilter);
aturFilter();
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
