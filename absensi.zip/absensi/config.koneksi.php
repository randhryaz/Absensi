
<?php
$host = "localhost";
$db   = "absensi_muhayo";
$user = "root";
$pass = "";

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (PDOException $e) {
    die("Koneksi database gagal.");
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('BATAS_SESSION', 28800);

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function tokenAktif() {
    $token = $_GET['tab_token'] ?? $_POST['tab_token'] ?? '';

    if (!$token && isset($_SESSION['tab_token'])) {
        $token = $_SESSION['tab_token'];
    }

    return is_string($token) && preg_match('/^[a-f0-9]{64}$/', $token)
        ? $token : '';
}

function wajibLogin() {
    global $pdo;

    $token = tokenAktif();

    if (!$token) {
        header("Location: auth.login.php");
        exit;
    }

    $hash = hash('sha256', $token);

    $stmt = $pdo->prepare(
        "SELECT * FROM user_sessions WHERE token_hash = ?"
    );
    $stmt->execute([$hash]);
    $akun = $stmt->fetch();

    if (!$akun || time() - (int)$akun['last_activity'] > BATAS_SESSION) {
        if ($akun) {
            $stmt = $pdo->prepare(
                "DELETE FROM user_sessions WHERE token_hash = ?"
            );
            $stmt->execute([$hash]);
        }

        header("Location: auth.login.php?expired=1");
        exit;
    }

    $stmt = $pdo->prepare(
        "UPDATE user_sessions SET last_activity = ? WHERE token_hash = ?"
    );
    $stmt->execute([time(), $hash]);

    $_SESSION['user'] = [
        'id' => $akun['user_id'],
        'nama' => $akun['nama'],
        'role' => $akun['role']
    ];

    $_SESSION['tab_token'] = $token;
}

function wajibRole($role) {
    wajibLogin();

    if (($_SESSION['user']['role'] ?? '') !== $role) {
        http_response_code(403);
        exit("Akses ditolak! Role tidak sesuai.");
    }
}

function csrfToken() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf'];
}

function cekCsrf() {
    if (
        !isset($_POST['csrf']) ||
        !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])
    ) {
        http_response_code(403);
        exit("Token keamanan tidak valid!");
    }
}
