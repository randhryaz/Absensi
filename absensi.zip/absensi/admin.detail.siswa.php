<?php
require 'config.koneksi.php';
wajibRole('admin');

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("
    SELECT s.id,s.nis,s.nama,k.nama_kelas,a.username
    FROM siswa s
    LEFT JOIN kelas k ON s.kelas_id=k.id
    LEFT JOIN akun_siswa a ON a.siswa_id=s.id
    WHERE s.id=?
");
$stmt->execute([$id]);
$siswa = $stmt->fetch();

if (!$siswa) {
    http_response_code(404);
    exit('Siswa tidak ditemukan!');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Detail Siswa</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #60a5fa 100%);
        min-height: 100vh;
        color: #1e293b;
    }
    .custom-container {
        max-width: 600px;
    }
    .card {
        border: none;
        border-radius: 14px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        background-color: #ffffff;
    }
    .back-link {
        color: #e2e8f0;
        text-decoration: none;
        font-weight: 500;
        display: inline-block;
        margin-bottom: 15px;
        transition: color 0.2s;
    }
    .back-link:hover {
        color: #ffffff;
        text-decoration: underline;
    }
    .detail-label {
        color: #64748b;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .detail-value {
        font-size: 1.1rem;
        font-weight: 600;
        color: #1e293b;
    }
</style>
</head>
<body>
<div class="container custom-container py-5">

<a href="admin.siswa.php" class="back-link">← Kembali</a>

<div class="card p-4 p-md-5">
<div class="text-center mb-4">
<div style="font-size: 60px;" class="mb-2">👨‍🎓</div>
<h4 class="fw-bold text-dark">Detail Akun Siswa</h4>
<p class="text-muted small">Informasi lengkap data akademik dan akun siswa</p>
</div>
<hr class="text-muted mb-4">

<div class="mb-3">
<div class="detail-label">ID Siswa</div>
<div class="detail-value">#<?= (int)$siswa['id'] ?></div>
</div>

<div class="mb-3">
<div class="detail-label">Nomor Induk Siswa (NIS)</div>
<div class="detail-value"><?= e($siswa['nis']) ?></div>
</div>

<div class="mb-3">
<div class="detail-label">Nama Lengkap</div>
<div class="detail-value"><?= e($siswa['nama']) ?></div>
</div>

<div class="mb-3">
<div class="detail-label">Kelas</div>
<div class="detail-value"><?= e($siswa['nama_kelas'] ?? '-') ?></div>
</div>

<div class="mb-3">
<div class="detail-label">Username Login</div>
<div class="detail-value">
<?php if (!empty($siswa['username'])): ?>
<span class="badge bg-primary px-3 py-2"><?= e($siswa['username']) ?></span>
<?php else: ?>
<span class="badge bg-secondary px-3 py-2">Belum ada akun</span>
<?php endif; ?>
</div>
</div>

</div>

</div>
</body>
</html>