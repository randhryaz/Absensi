<?php
require 'config.koneksi.php';
wajibRole('admin');

$pesan = '';
$jenis = 'info';

// Direktori penyimpanan file background
$uploadDir = 'uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cekCsrf();

    try {
        if (!isset($_FILES['bg_file']) || $_FILES['bg_file']['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('Pilih file gambar terlebih dahulu!');
        }

        $fileTmp = $_FILES['bg_file']['tmp_name'];
        $fileName = $_FILES['bg_file']['name'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        // Validasi ekstensi gambar
        $allowedExt = ['jpg', 'jpeg', 'png', 'webp'];
        if (!in_array($fileExt, $allowedExt)) {
            throw new Exception('Format file harus berupa JPG, JPEG, PNG, atau WEBP!');
        }

        // Buat nama file unik agar tidak bentrok
        $newFileName = 'bg_login_' . time() . '.' . $fileExt;
        $destination = $uploadDir . $newFileName;

        if (!move_uploaded_file($fileTmp, $destination)) {
            throw new Exception('Gagal mengunggah file ke server.');
        }

        // Ambil data background lama untuk dihapus (opsional, agar server tidak penuh)
        $stmtOld = $pdo->prepare("SELECT nilai FROM setting WHERE param = 'bg_login'");
        $stmtOld->execute();
        $oldBg = $stmtOld->fetchColumn();

        if ($oldBg && $oldBg !== 'default_bg.jpg' && file_exists($uploadDir . $oldBg)) {
            @unlink($uploadDir . $oldBg);
        }

        // Simpan nama file baru ke database
        $stmtUpdate = $pdo->prepare("UPDATE setting SET nilai = ? WHERE param = 'bg_login'");
        $stmtUpdate->execute([$newFileName]);

        $pesan = 'Background halaman login berhasil diperbarui!';
        $jenis = 'success';

    } catch (Throwable $e) {
        $pesan = 'Gagal: ' . $e->getMessage();
        $jenis = 'danger';
    }
}

// Ambil background aktif saat ini
$stmtBg = $pdo->prepare("SELECT nilai FROM setting WHERE param = 'bg_login'");
$stmtBg->execute();
$currentBg = $stmtBg->fetchColumn() ?: 'default_bg.jpg';
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pengaturan Background Login - SMK MUHAYO</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #60a5fa 100%);
        min-height: 100vh;
        color: #1e293b;
    }
    .custom-container {
        max-width: 800px;
    }
    .card {
        border: none;
        border-radius: 14px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        background-color: #ffffff;
    }
    .back-link {
        color: #e2e8f0;
        text-decoration: none;
        font-weight: 500;
        display: inline-block;
        margin-bottom: 15px;
        transition: color 0.2s;
    }
    .back-link:hover {
        color: #ffffff;
        text-decoration: underline;
    }
    h3 {
        color: #ffffff;
        font-weight: 700;
    }
    .preview-bg {
        width: 100%;
        height: 200px;
        object-fit: cover;
        border-radius: 10px;
        border: 2px solid #cbd5e1;
    }
</style>
</head>
<body class="bg-light">

<div class="container custom-container py-5">
<a href="admin.dashboard.php" class="back-link" style="display:inline-block;background:#dc3545;color:#fff;text-decoration:none;padding:7px 13px;border-radius:6px;width:fit-content;margin-bottom:15px;font-weight:500">← Kembali</a>
<h3 class="my-3">Pengaturan Background Login</h3>

<?php if($pesan): ?>
<div class="alert alert-<?= e($jenis) ?> shadow-sm"><?= e($pesan) ?></div>
<?php endif; ?>

<div class="card shadow-sm p-4 mb-4">
<h5 class="text-primary fw-bold mb-3">🖼️ Preview Background Saat Ini</h5>
<div class="mb-4 text-center">
    <?php if(file_exists('uploads/' . $currentBg)): ?>
        <img src="uploads/<?= e($currentBg) ?>" alt="Background Login" class="preview-bg">
    <?php else: ?>
        <p class="text-muted">Belum ada background kustom yang diunggah (menggunakan default sistem).</p>
    <?php endif; ?>
</div>

<h5 class="text-primary fw-bold mb-3">Ganti Background Login Baru</h5>
<form method="POST" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">

<div class="mb-3">
    <label for="bg_file" class="form-label fw-semibold">Pilih Gambar (JPG, PNG, WEBP)</label>
    <input type="file" name="bg_file" id="bg_file" class="form-control" accept=".jpg, .jpeg, .png, .webp" required>
    <div class="form-text">Disarankan menggunakan gambar beresolusi tinggi (minimal 1920x1080 piksel).</div>
</div>

<button type="submit" class="btn btn-success px-4 fw-semibold">💾 Simpan & Perbarui Background</button>
</form>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>