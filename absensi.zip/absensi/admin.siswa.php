
<?php
require 'config.koneksi.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

wajibRole('admin');

$pesan = '';
$jenis = 'info';

$akunBaru = $_SESSION['akun_baru'] ?? null;
unset($_SESSION['akun_baru']);

// Background halaman
$bgQuery = $pdo->prepare("
    SELECT value_text FROM settings
    WHERE key_name = 'bg_siswa'
");
$bgQuery->execute();
$customBg = $bgQuery->fetchColumn();

$bgStyle = $customBg
    ? "background: url('" . e($customBg) . "') no-repeat center center fixed; background-size: cover;"
    : "background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #60a5fa 100%);";

if (isset($_GET['berhasil'])) {
    $pesan = 'Data siswa berhasil diperbarui!';
    $jenis = 'success';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cekCsrf();

    try {

        // TAMBAH SISWA DAN AKUN OTOMATIS
        if (isset($_POST['tambah'])) {

            $nis = trim($_POST['nis']);
            $nama = trim($_POST['nama']);
            $kelas_id = (int) $_POST['kelas_id'];

            if ($nis === '' || $nama === '' || $kelas_id <= 0) {
                throw new Exception('Semua data wajib diisi!');
            }

            $passwordBaru = (string) random_int(10000000, 99999999);
            $usernameBaru = $nis;

            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                INSERT INTO siswa (nis, nama, kelas_id)
                VALUES (?, ?, ?)
            ");
            $stmt->execute([$nis, $nama, $kelas_id]);

            $siswaId = $pdo->lastInsertId();

            $stmt = $pdo->prepare("
                INSERT INTO akun_siswa (siswa_id, username, password)
                VALUES (?, ?, ?)
            ");

            $stmt->execute([
                $siswaId,
                $usernameBaru,
                password_hash($passwordBaru, PASSWORD_DEFAULT)
            ]);

            $pdo->commit();

            $_SESSION['akun_baru'] = [
                'nama' => $nama,
                'username' => $usernameBaru,
                'password' => $passwordBaru
            ];

            header("Location: admin.siswa.php");
            exit;
        }

        // EDIT SISWA
        elseif (isset($_POST['edit'])) {

            $id = (int) $_POST['id'];
            $nis = trim($_POST['nis']);
            $nama = trim($_POST['nama']);
            $kelas_id = (int) $_POST['kelas_id'];
            $username = trim($_POST['username']);
            $password = $_POST['password'] ?? '';

            if ($nis === '' || $nama === '' || $username === '') {
                throw new Exception('Semua data wajib diisi!');
            }

            if ($password !== '' && !preg_match('/^[0-9]{8}$/', $password)) {
                throw new Exception('Password harus tepat 8 angka!');
            }

            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                UPDATE siswa
                SET nis = ?, nama = ?, kelas_id = ?
                WHERE id = ?
            ");
            $stmt->execute([$nis, $nama, $kelas_id, $id]);

            $stmt = $pdo->prepare("
                SELECT id FROM akun_siswa WHERE siswa_id = ?
            ");
            $stmt->execute([$id]);
            $akun = $stmt->fetch();

            if ($akun) {

                if ($password !== '') {
                    $stmt = $pdo->prepare("
                        UPDATE akun_siswa
                        SET username = ?, password = ?
                        WHERE siswa_id = ?
                    ");

                    $stmt->execute([
                        $username,
                        password_hash($password, PASSWORD_DEFAULT),
                        $id
                    ]);
                } else {
                    $stmt = $pdo->prepare("
                        UPDATE akun_siswa
                        SET username = ?
                        WHERE siswa_id = ?
                    ");
                    $stmt->execute([$username, $id]);
                }

            } else {

                if ($password === '') {
                    throw new Exception('Masukkan password 8 angka untuk membuat akun!');
                }

                $stmt = $pdo->prepare("
                    INSERT INTO akun_siswa (siswa_id, username, password)
                    VALUES (?, ?, ?)
                ");

                $stmt->execute([
                    $id,
                    $username,
                    password_hash($password, PASSWORD_DEFAULT)
                ]);
            }

            $pdo->commit();

            header("Location: admin.siswa.php?berhasil=edit");
            exit;
        }

        // HAPUS BANYAK SISWA
        elseif (isset($_POST['hapus_banyak'])) {

            $ids = array_values(array_unique(array_filter(
                array_map('intval', $_POST['pilih'] ?? []),
                fn($id) => $id > 0
            )));

            if (!$ids) {
                throw new Exception('Pilih siswa terlebih dahulu!');
            }

            $marks = implode(',', array_fill(0, count($ids), '?'));

            $stmt = $pdo->prepare("
                DELETE FROM siswa WHERE id IN ($marks)
            ");
            $stmt->execute($ids);

            header("Location: admin.siswa.php?berhasil=hapus");
            exit;
        }

        // HAPUS SATU SISWA
        elseif (isset($_POST['hapus'])) {

            $stmt = $pdo->prepare("
                DELETE FROM siswa WHERE id = ?
            ");
            $stmt->execute([(int) $_POST['hapus']]);

            header("Location: admin.siswa.php?berhasil=hapus");
            exit;
        }

    } catch (Throwable $e) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        $pesan = $e instanceof PDOException
            ? 'Gagal! Periksa NIS, username, atau relasi database.'
            : $e->getMessage();

        $jenis = 'danger';
    }
}

$kelas = $pdo->query("
    SELECT * FROM kelas ORDER BY nama_kelas
")->fetchAll();

$data = $pdo->query("
    SELECT s.*, k.nama_kelas, a.username
    FROM siswa s
    JOIN kelas k ON s.kelas_id = k.id
    LEFT JOIN akun_siswa a ON a.siswa_id = s.id
    ORDER BY k.nama_kelas, s.nama
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Data Siswa - SMK Muhammadiyah 2 Yogyakarta</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="style.css" rel="stylesheet">

<style>
body {
    <?= $bgStyle ?>
    min-height: 100vh;
    color: #1e293b;
}
.custom-container {
    max-width: 1000px;
}
.card {
    border: none;
    border-radius: 14px;
    box-shadow: 0 10px 25px rgba(0,0,0,.15);
    background-color: #fff;
}
.back-link {
    color: #e2e8f0;
    text-decoration: none;
    font-weight: 500;
    display: inline-block;
    margin-bottom: 15px;
}
.back-link:hover {
    color: #fff;
    text-decoration: underline;
}
h3 {
    color: #fff;
    font-weight: 700;
}
.table-container {
    background: #fff;
    border-radius: 10px;
    overflow: hidden;
}
.btn-import-excel {
    background-color: #16a34a;
    border-color: #15803d;
    color: #fff;
}
.btn-import-excel:hover {
    background-color: #15803d;
    border-color: #166534;
    color: #fff;
}
</style>
</head>

<body>

<div class="container custom-container py-5">

<a href="admin.dashboard.php" class="back-link" style="display:inline-block;background:#dc3545;color:#fff;text-decoration:none;padding:7px 13px;border-radius:6px;width:fit-content;margin-bottom:15px;font-weight:500">← Kembali</a>

<h3 class="my-3">Data Siswa</h3>

<?php if ($pesan): ?>
<div class="alert alert-<?= e($jenis) ?> shadow-sm">
    <?= e($pesan) ?>
</div>
<?php endif; ?>

<?php if ($akunBaru): ?>
<div class="alert alert-success shadow-sm">
    <h5 class="fw-bold">Akun Siswa Berhasil Dibuat!</h5>

    <p class="mb-1">
        Nama: <b><?= e($akunBaru['nama']) ?></b>
    </p>

    <p class="mb-1">
        Username: <b><?= e($akunBaru['username']) ?></b>
    </p>

    <p class="mb-2">
        Password: <b><?= e($akunBaru['password']) ?></b>
    </p>

    <button type="button" class="btn btn-sm btn-success"
        onclick="navigator.clipboard.writeText(<?= e(json_encode($akunBaru['username'] . "\n" . $akunBaru['password'])) ?>)">
        Salin Username & Password
    </button>

    <div class="small mt-2">
        Simpan informasi akun ini sebelum meninggalkan halaman.
    </div>
</div>
<?php endif; ?>

<a href="admin.import.siswa.php"
   class="btn btn-import-excel mb-4 fw-semibold px-4 shadow-sm">
   📥 Import Siswa Excel
</a>

<div class="card shadow-sm p-4 mb-4">

<h5 class="text-primary fw-bold mb-3">➕ Tambah Siswa Baru</h5>

<form method="POST">
<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">

<div class="mb-2">
<input name="nis" class="form-control" placeholder="NIS" required>
</div>

<div class="mb-2">
<input name="nama" class="form-control" placeholder="Nama siswa" required>
</div>

<div class="mb-3">
<select name="kelas_id" class="form-select" required>
<option value="">Pilih kelas</option>
<?php foreach ($kelas as $k): ?>
<option value="<?= (int)$k['id'] ?>">
<?= e($k['nama_kelas']) ?>
</option>
<?php endforeach; ?>
</select>
</div>

<button name="tambah" class="btn btn-primary px-4 fw-semibold">
Tambah Siswa
</button>

</form>
</div>

<div class="card shadow-sm p-4">

<h5 class="text-primary fw-bold mb-3">📋 Daftar Siswa</h5>

<form method="POST" id="formHapus">
<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">

<div class="d-flex gap-2 flex-wrap mb-3">

<button name="hapus_banyak" value="1"
class="btn btn-danger btn-sm px-3 fw-semibold"
onclick="return konfirmasiHapus()">
Hapus Siswa Terpilih
</button>

<button type="button"
class="btn btn-outline-primary btn-sm px-3 fw-semibold"
onclick="pilihSemua()">
Pilih Semua
</button>

<button type="button"
class="btn btn-outline-secondary btn-sm px-3 fw-semibold"
onclick="batalkanPilihan()">
Batalkan Pilihan
</button>

</div>

<div class="table-responsive table-container">

<table class="table table-hover align-middle mb-0">

<thead class="table-light">
<tr>
<th style="width:40px;">
<input type="checkbox" id="semua" onchange="toggleSemua(this)">
</th>
<th>NIS</th>
<th>Nama</th>
<th>Kelas</th>
<th>Username</th>
<th class="text-end" style="width:180px;">Aksi</th>
</tr>
</thead>

<tbody>

<?php foreach ($data as $s): ?>

<tr>

<td>
<input type="checkbox" class="pilih"
name="pilih[]" value="<?= (int)$s['id'] ?>">
</td>

<td class="fw-semibold"><?= e($s['nis']) ?></td>
<td class="fw-semibold"><?= e($s['nama']) ?></td>
<td><?= e($s['nama_kelas']) ?></td>

<td>
<?php if (!empty($s['username'])): ?>
<span class="badge bg-secondary">
<?= e($s['username']) ?>
</span>
<?php else: ?>
<span class="text-muted small">-</span>
<?php endif; ?>
</td>

<td class="text-end text-nowrap">

<a href="admin.detail.siswa.php?id=<?= (int)$s['id'] ?>"
class="btn btn-info btn-sm text-white px-2 py-1"
title="Lihat Detail">👁</a>

<button type="button"
class="btn btn-warning btn-sm px-2 py-1 text-dark fw-semibold"
data-bs-toggle="collapse"
data-bs-target="#edit<?= (int)$s['id'] ?>">
Edit
</button>

<button type="submit" form="formHapus"
name="hapus" value="<?= (int)$s['id'] ?>"
class="btn btn-danger btn-sm px-2 py-1"
onclick="return confirm('Yakin menghapus siswa ini?')">
Hapus
</button>

</td>
</tr>

<tr class="collapse bg-light" id="edit<?= (int)$s['id'] ?>">
<td colspan="6">

<form method="POST" class="p-3">

<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">
<input type="hidden" name="id" value="<?= (int)$s['id'] ?>">

<div class="mb-2">
<label class="form-label fw-semibold">NIS</label>
<input name="nis" class="form-control"
value="<?= e($s['nis']) ?>" required>
</div>

<div class="mb-2">
<label class="form-label fw-semibold">Nama</label>
<input name="nama" class="form-control"
value="<?= e($s['nama']) ?>" required>
</div>

<div class="mb-2">
<label class="form-label fw-semibold">Kelas</label>
<select name="kelas_id" class="form-select" required>

<?php foreach ($kelas as $k): ?>
<option value="<?= (int)$k['id'] ?>"
<?= $s['kelas_id'] == $k['id'] ? 'selected' : '' ?>>
<?= e($k['nama_kelas']) ?>
</option>
<?php endforeach; ?>

</select>
</div>

<div class="mb-2">
<label class="form-label fw-semibold">Username</label>
<input name="username" class="form-control"
value="<?= e($s['username'] ?? '') ?>" required>
</div>

<div class="mb-3">
<label class="form-label fw-semibold">
Password baru (kosongkan jika tidak diganti)
</label>

<input type="password"
name="password"
class="form-control"
inputmode="numeric"
pattern="[0-9]{8}"
minlength="8"
maxlength="8"
placeholder="Masukkan 8 angka"
title="Password harus tepat 8 angka">
</div>

<button name="edit" class="btn btn-success px-4 fw-semibold">
Simpan Perubahan
</button>

</form>
</td>
</tr>

<?php endforeach; ?>

<?php if (!$data): ?>
<tr>
<td colspan="6" class="text-center text-muted py-3">
Belum ada siswa.
</td>
</tr>
<?php endif; ?>

</tbody>
</table>
</div>
</form>
</div>

</div>

<script>
function toggleSemua(el) {
    document.querySelectorAll('.pilih').forEach(c => c.checked = el.checked);
}

function pilihSemua() {
    document.querySelectorAll('.pilih').forEach(c => c.checked = true);
    document.getElementById('semua').checked = true;
}

function batalkanPilihan() {
    document.querySelectorAll('.pilih').forEach(c => c.checked = false);
    document.getElementById('semua').checked = false;
}

function konfirmasiHapus() {
    const n = document.querySelectorAll('.pilih:checked').length;

    if (!n) {
        alert('Pilih siswa terlebih dahulu!');
        return false;
    }

    return confirm('Hapus ' + n + ' siswa beserta akun dan riwayat absensinya?');
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
