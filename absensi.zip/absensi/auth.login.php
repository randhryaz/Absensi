
<?php
require 'config.koneksi.php';

$error = '';

$bgStyle = "background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #60a5fa 100%);";

try {
    $stmtBg = $pdo->prepare("SELECT nilai FROM setting WHERE param = 'bg_login'");
    $stmtBg->execute();
    $bgFile = $stmtBg->fetchColumn();

    if ($bgFile && file_exists('uploads/' . $bgFile)) {
        $bgStyle = "background: url('uploads/" . e($bgFile) . "') no-repeat center center fixed; background-size: cover;";
    }
} catch (Throwable $e) {
    // Gunakan background default
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cekCsrf();

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $akun = null;

    // Login admin atau guru
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $u = $stmt->fetch();

    if ($u && password_verify($password, $u['password'])) {
        $akun = [
            'id' => $u['id'],
            'nama' => $u['nama'],
            'role' => $u['role']
        ];
    } else {
        // Login siswa
        $stmt = $pdo->prepare("
            SELECT a.*, s.nama, s.id AS siswa_id
            FROM akun_siswa a
            JOIN siswa s ON s.id = a.siswa_id
            WHERE a.username = ?
        ");
        $stmt->execute([$username]);
        $s = $stmt->fetch();

        if ($s && password_verify($password, $s['password'])) {
            $akun = [
                'id' => $s['siswa_id'],
                'nama' => $s['nama'],
                'role' => 'siswa'
            ];
        }
    }

    if ($akun) {
        // Buat token khusus tab ini
        $tabToken = bin2hex(random_bytes(32));
        $hash = hash('sha256', $tabToken);

        $stmt = $pdo->prepare("
            INSERT INTO user_sessions
            (token_hash, user_id, nama, role, last_activity)
            VALUES (?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $hash,
            $akun['id'],
            $akun['nama'],
            $akun['role'],
            time()
        ]);

        // Simpan token untuk tab login ini
        $_SESSION['tab_token'] = $tabToken;
        $_SESSION['user'] = $akun;
        $_SESSION['last_activity'] = time();

        // Arahkan ke dashboard
        header("Location: index.php?tab_token=" . $tabToken);
        exit;
    }

    $error = "Username atau password salah!";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login - SMK Muhammadiyah 2 Yogyakarta</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    <?= $bgStyle ?>
    min-height: 100vh;
    color: #1e293b;
}
.login-card {
    border: none;
    border-radius: 16px;
    box-shadow: 0 15px 35px rgba(0,0,0,.25);
    background-color: rgba(255,255,255,.96);
    width: 100%;
    max-width: 420px;
}
h3 {
    color: #1e3a8a;
    font-weight: 700;
}
.form-label {
    font-weight: 600;
    color: #334155;
}
.btn-primary {
    background-color: #2563eb;
    border: none;
    font-weight: 600;
    padding: 10px;
}
.btn-primary:hover {
    background-color: #1d4ed8;
}
</style>
</head>

<body>
<div class="container min-vh-100 d-flex align-items-center justify-content-center py-5">
<div class="card login-card p-4 p-md-5">

<div class="text-center mb-4">
<div style="font-size:55px;" class="mb-2">🎓</div>
<h3 class="mb-1" style="font-size:1.3rem;">
SMK Muhammadiyah 2<br>Yogyakarta
</h3>
<p class="text-muted small mt-2">Sistem Absensi Sekolah</p>
</div>

<?php if ($error): ?>
<div class="alert alert-danger"><?= e($error) ?></div>
<?php endif; ?>

<form method="POST">
<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">

<div class="mb-3">
<label class="form-label">Username</label>
<input name="username" class="form-control"
placeholder="Masukkan username" required
autocomplete="username">
</div>

<div class="mb-4">
<label class="form-label">Password</label>
<input type="password" name="password"
class="form-control" placeholder="Masukkan password"
required autocomplete="current-password">
</div>

<button class="btn btn-primary w-100 shadow-sm">
LOGIN
</button>
</form>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
