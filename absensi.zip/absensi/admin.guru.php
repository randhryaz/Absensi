<?php
require 'config.koneksi.php';
require_once 'fungsi.akun.guru.php';
wajibRole('admin');

$pesan = '';
$jenis = 'info';

// Menggunakan background gradasi warna standar (tanpa foto)
$bgStyle = "background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #60a5fa 100%);";

if (isset($_GET['berhasil'])) {
    $pesan = match($_GET['berhasil']) {
        'tambah' => 'Data guru baru berhasil ditambahkan!',
        'edit'   => 'Data guru berhasil diperbarui!',
        'hapus'  => 'Data guru berhasil dihapus!',
        default  => 'Operasi berhasil dilakukan.'
    };
    $jenis = 'success';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cekCsrf();

    try {
        // TAMBAH GURU: akun login otomatis
        if (isset($_POST['tambah'])) {
            $nbm = trim($_POST['nbm'] ?? '');
            $nama = trim($_POST['nama'] ?? '');
            if ($nbm === '' || $nama === '') throw new Exception("NBM dan nama guru wajib diisi!");
            $akunBaru = buatAkunGuruOtomatis($nbm, $nama, $pdo);
            $_SESSION['akun_guru_baru'] = $akunBaru;
            header("Location: admin.guru.php?berhasil=tambah");
            exit;
        }

        // FITUR EDIT GURU
        elseif (isset($_POST['edit'])) {
            $id       = (int)$_POST['id'];
            $nbm      = trim($_POST['nbm'] ?? '');
            $nama     = trim($_POST['nama']);
            $username = trim($_POST['username']);
            $password = $_POST['password'] ?? '';

            if (!$nbm || !$nama || !$username) {
                throw new Exception("NBM, nama, dan username wajib diisi!");
            }

            if ($password !== '' && strlen($password) < 8) {
                throw new Exception("Password minimal 8 karakter!");
            }

            // Cek duplikasi username pada user lain
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
            $stmt->execute([$username, $id]);
            if ($stmt->fetch()) {
                throw new Exception("Username '{$username}' sudah digunakan oleh pengguna lain!");
            }

            $cekNbm = $pdo->prepare("SELECT id FROM users WHERE nbm = ? AND id != ? AND role = 'guru'");
            $cekNbm->execute([$nbm, $id]);
            if ($cekNbm->fetch()) throw new Exception('NBM sudah digunakan guru lain!');

            if ($password !== '') {
                $stmt = $pdo->prepare("
                    UPDATE users SET nbm = ?, nama = ?, username = ?, password = ?, password_terenkripsi = ? 
                    WHERE id = ? AND role = 'guru'
                ");
                $stmt->execute([
                    $nbm,
                    $nama,
                    $username,
                    password_hash($password, PASSWORD_DEFAULT),
                    enkripsiPasswordGuru($password),
                    $id
                ]);
            } else {
                $stmt = $pdo->prepare("
                    UPDATE users SET nbm = ?, nama = ?, username = ? 
                    WHERE id = ? AND role = 'guru'
                ");
                $stmt->execute([
                    $nbm,
                    $nama,
                    $username,
                    $id
                ]);
            }

            header("Location: admin.guru.php?berhasil=edit");
            exit;
        }

        // FITUR HAPUS BANYAK (MASSAL)
        elseif (isset($_POST['hapus_banyak'])) {
            $ids = array_values(array_unique(array_filter(
                array_map('intval', $_POST['pilih'] ?? []),
                fn($id) => $id > 0
            )));

            if (!$ids) {
                throw new Exception('Pilih guru terlebih dahulu!');
            }

            $pdo->beginTransaction();
            $terhapus = 0;
            $gagal = 0;

            foreach ($ids as $id) {
                // Lepaskan penugasan wali kelas agar data kelas tetap aman.
                $stmt = $pdo->prepare("UPDATE kelas SET guru_id = NULL WHERE guru_id = ?");
                $stmt->execute([$id]);

                // Hapus sesi login guru agar akun yang dihapus tidak tetap aktif.
                $stmt = $pdo->prepare("DELETE FROM user_sessions WHERE user_id = ?");
                $stmt->execute([$id]);

                $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'guru'");
                $stmt->execute([$id]);
                if ($stmt->rowCount() > 0) {
                    $terhapus++;
                }
            }

            $pdo->commit();

            if ($gagal > 0) {
                $pesan = "Berhasil menghapus $terhapus guru. $gagal guru dilewati karena masih menjadi wali kelas.";
                $jenis = 'warning';
            } else {
                header("Location: admin.guru.php?berhasil=hapus");
                exit;
            }
        }

        // FITUR HAPUS SATUAN
        elseif (isset($_POST['hapus'])) {
            $id = (int)$_POST['hapus'];

            // Lepaskan penugasan wali kelas; data kelas dan siswa tetap dipertahankan.
            $stmt = $pdo->prepare("UPDATE kelas SET guru_id = NULL WHERE guru_id = ?");
            $stmt->execute([$id]);

            // Hapus sesi login yang terkait dengan akun guru.
            $stmt = $pdo->prepare("DELETE FROM user_sessions WHERE user_id = ?");
            $stmt->execute([$id]);

            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'guru'");
            $stmt->execute([$id]);
            if ($stmt->rowCount() < 1) {
                throw new Exception("Data guru tidak ditemukan atau sudah dihapus.");
            }

            header("Location: admin.guru.php?berhasil=hapus");
            exit;
        }

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $pesan = $e->getMessage();
        $jenis = 'danger';
    }
}

$data = $pdo->query("
    SELECT * FROM users
    WHERE role = 'guru'
    ORDER BY nama
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Data Guru - SMK Muhammadiyah 2 Yogyakarta</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="style.css" rel="stylesheet">
<style>
    body {
        <?= $bgStyle ?>
        min-height: 100vh;
        color: #1e293b;
    }
    .custom-container {
        max-width: 1000px;
    }
    .card {
        border: none;
        border-radius: 14px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        background-color: #ffffff;
    }
    .back-link {
        background: #dc3545; color: #fff; padding: 7px 13px; border-radius: 6px; width: fit-content;
        text-decoration: none;
        font-weight: 500;
        display: inline-block;
        margin-bottom: 15px;
        transition: color 0.2s;
    }
    .back-link:hover {
        background: #bb2d3b; color: #ffffff;
        text-decoration: underline;
    }
    h3 {
        color: #ffffff;
        font-weight: 700;
    }
    .table-container {
        background: #ffffff;
        border-radius: 10px;
        overflow: hidden;
    }
    /* Tombol import excel warna hijau solid */
    .btn-import-excel {
        background-color: #16a34a;
        border-color: #15803d;
        color: #ffffff;
    }
    .btn-import-excel:hover {
        background-color: #15803d;
        border-color: #166534;
        color: #ffffff;
    }
</style>
</head>
<body>

<div class="container custom-container py-5">
<a href="admin.dashboard.php" class="back-link" style="display:inline-block;background:#dc3545;color:#fff;text-decoration:none;padding:7px 13px;border-radius:6px;width:fit-content;margin-bottom:15px;font-weight:500">← Kembali</a>
<h3 class="my-3">Data Guru & Pengajar</h3>

<?php if (!empty($_SESSION['akun_guru_baru'])): $akunInfo = $_SESSION['akun_guru_baru']; unset($_SESSION['akun_guru_baru']); ?>
<div class="alert alert-success shadow-sm"><strong>Akun guru berhasil dibuat!</strong><br>Username: <code><?= e($akunInfo['username']) ?></code><br>Password: <code><?= e($akunInfo['password']) ?></code><br><small>Simpan informasi ini dan berikan kepada guru.</small></div>
<?php endif; ?>
<?php if($pesan): ?>
<div class="alert alert-<?= e($jenis) ?> shadow-sm"><?= e($pesan) ?></div>
<?php endif; ?>

<a href="admin.akun.guru.php" class="btn btn-dark mb-4 fw-semibold px-4 shadow-sm">🔑 Akun Login Guru</a>
<a href="admin.import.guru.php" class="btn btn-import-excel mb-4 fw-semibold px-4 shadow-sm">📥 Import Guru Excel</a>

<div class="card shadow-sm p-4 mb-4">
<h5 class="text-primary fw-bold mb-3">➕ Tambah Guru Baru</h5>
<form method="POST">
<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">
<div class="mb-2">
<input name="nbm" class="form-control" placeholder="NBM" required>
</div>
<div class="mb-2">
<input name="nama" class="form-control" placeholder="Nama Lengkap & Gelar" required>
</div>
<div class="alert alert-info small">Username menggunakan NBM dan password 12 karakter akan dibuat otomatis.</div>
<button name="tambah" class="btn btn-primary px-4 fw-semibold">Tambah Guru</button>
</form>
</div>

<div class="card shadow-sm p-4">
<h5 class="text-primary fw-bold mb-3">📋 Daftar Guru</h5>

<form method="POST" id="formHapus">
<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">
</form>

<div class="d-flex gap-2 flex-wrap mb-3">
<button type="submit" form="formHapus" name="hapus_banyak" value="1" class="btn btn-danger btn-sm px-3 fw-semibold" onclick="return konfirmasiHapus()">Hapus Guru Terpilih</button>
<button type="button" class="btn btn-outline-primary btn-sm px-3 fw-semibold" onclick="pilihSemua()">Pilih Semua</button>
<button type="button" class="btn btn-outline-secondary btn-sm px-3 fw-semibold" onclick="batalkanPilihan()">Batalkan Pilihan</button>
</div>

<div class="table-responsive table-container">
<table class="table table-hover align-middle mb-0">
<thead class="table-light">
<tr>
<th style="width: 40px;"><input type="checkbox" id="semua" onchange="toggleSemua(this)"></th>
<th>NBM</th>
<th>Nama Guru</th>
<th>Username</th>
<th class="text-end" style="width: 180px;">Aksi</th>
</tr>
</thead>
<tbody>

<?php foreach($data as $g): ?>
<tr>
<td><input type="checkbox" form="formHapus" class="pilih" name="pilih[]" value="<?= (int)$g['id'] ?>"></td>
<td><?= e($g['nbm'] ?? '-') ?></td>
<td class="fw-semibold"><?= e($g['nama']) ?></td>
<td>
<?php if(!empty($g['username'])): ?>
<span class="badge bg-secondary"><?= e($g['username']) ?></span>
<?php else: ?>
<span class="text-muted small">-</span>
<?php endif; ?>
</td>
<td class="text-end text-nowrap">
<button type="button" class="btn btn-warning btn-sm px-2 py-1 text-dark fw-semibold" data-bs-toggle="collapse" data-bs-target="#edit<?= (int)$g['id'] ?>">Edit</button>

<button type="submit" form="formHapus" name="hapus" value="<?= (int)$g['id'] ?>" class="btn btn-danger btn-sm px-2 py-1" onclick="return confirm('Yakin ingin menghapus guru ini?')">Hapus</button>
</td>
</tr>

<tr class="collapse bg-light" id="edit<?= (int)$g['id'] ?>">
<td colspan="5">
<div class="p-3 border rounded bg-white my-2">
<form method="POST">
<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">
<input type="hidden" name="id" value="<?= (int)$g['id'] ?>">

<div class="mb-2">
<label class="form-label fw-semibold">NBM</label>
<input name="nbm" class="form-control mb-2" value="<?= e($g['nbm'] ?? '') ?>" required>
<label class="form-label fw-semibold">Nama Lengkap & Gelar</label>
<input name="nama" class="form-control" value="<?= e($g['nama']) ?>" required>
</div>

<div class="mb-2">
<label class="form-label fw-semibold">Username</label>
<input name="username" class="form-control" value="<?= e($g['username']) ?>" required>
</div>

<div class="mb-3">
<label class="form-label fw-semibold">Password baru (kosongkan jika tidak diganti)</label>
<input type="password" name="password" class="form-control" minlength="8" placeholder="Minimal 8 karakter jika diisi">
</div>

<button type="submit" name="edit" class="btn btn-success px-4 fw-semibold">Simpan Perubahan</button>
</form>
</div>
</td>
</tr>
<?php endforeach; ?>

<?php if(!$data): ?>
<tr><td colspan="5" class="text-center text-muted py-3">Belum ada data guru.</td></tr>
<?php endif; ?>

</tbody>
</table>
</div>
</div>
</div>

<script>
function toggleSemua(el){document.querySelectorAll('.pilih').forEach(c=>c.checked=el.checked);}
function pilihSemua(){document.querySelectorAll('.pilih').forEach(c=>c.checked=true);document.getElementById('semua').checked=true;}
function batalkanPilihan(){document.querySelectorAll('.pilih').forEach(c=>c.checked=false);document.getElementById('semua').checked=false;}
function konfirmasiHapus(){
 const n = document.querySelectorAll('.pilih:checked').length;
 if(!n){alert('Pilih guru terlebih dahulu!');return false;}
 return confirm('Yakin ingin menghapus '+n+' guru yang dipilih?');
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>