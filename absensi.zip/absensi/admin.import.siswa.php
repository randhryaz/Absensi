<?php
require 'config.koneksi.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

wajibRole('admin');

$pesan = '';
$jenis = 'info';

// =====================================
// DOWNLOAD FILE AKUN SISWA
// =====================================

if (isset($_GET['download_akun'])) {

    $file = $_SESSION['file_akun_siswa'] ?? '';

    if ($file && is_file($file)) {

        unset($_SESSION['file_akun_siswa']);

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="akun_siswa_' . date('Ymd_His') . '.csv"');
        header('Content-Length: ' . filesize($file));

        readfile($file);
        unlink($file);
        exit;

    } else {
        $pesan = 'File akun tidak ditemukan atau sudah diunduh.';
        $jenis = 'danger';
    }
}

// =====================================
// PROSES IMPORT SISWA DAN AKUN OTOMATIS
// =====================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    cekCsrf();

    if (
        isset($_FILES['file_excel']) &&
        $_FILES['file_excel']['error'] === UPLOAD_ERR_OK
    ) {

        $fileTmpPath = $_FILES['file_excel']['tmp_name'];
        $fileName = $_FILES['file_excel']['name'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if ($fileExtension !== 'csv') {

            $pesan = 'Format file harus CSV (.csv)!';
            $jenis = 'danger';

        } else {

            try {

                $handle = fopen($fileTmpPath, 'r');

                if (!$handle) {
                    throw new Exception('Gagal membaca file CSV!');
                }

                // Bersihkan file akun sebelumnya jika belum diunduh
                if (!empty($_SESSION['file_akun_siswa'])) {
                    $fileLama = $_SESSION['file_akun_siswa'];

                    if (is_file($fileLama)) {
                        unlink($fileLama);
                    }

                    unset($_SESSION['file_akun_siswa']);
                }

                $pdo->beginTransaction();

                $berhasil = 0;
                $gagal = 0;
                $akunBerhasil = [];

                // Lewati header CSV
                fgetcsv($handle);

                // Siapkan query agar lebih efisien
                $stmtKelas = $pdo->prepare("
                    SELECT id FROM kelas
                    WHERE nama_kelas = ?
                ");

                $stmtCekNis = $pdo->prepare("
                    SELECT id FROM siswa
                    WHERE nis = ?
                ");

                $stmtCekUser = $pdo->prepare("
                    SELECT id FROM akun_siswa
                    WHERE username = ?
                ");

                $stmtSiswa = $pdo->prepare("
                    INSERT INTO siswa (nis, nama, kelas_id)
                    VALUES (?, ?, ?)
                ");

                $stmtAkun = $pdo->prepare("
                    INSERT INTO akun_siswa
                    (siswa_id, username, password)
                    VALUES (?, ?, ?)
                ");

                while (($row = fgetcsv($handle)) !== false) {

                    $nis = trim($row[0] ?? '');
                    $nama = trim($row[1] ?? '');
                    $nama_kelas = trim($row[2] ?? '');

                    // Validasi data
                    if (
                        $nis === '' ||
                        $nama === '' ||
                        $nama_kelas === ''
                    ) {
                        $gagal++;
                        continue;
                    }

                    // Username otomatis menggunakan NIS
                    $username = $nis;

                    // Cari kelas
                    $stmtKelas->execute([$nama_kelas]);
                    $kelas = $stmtKelas->fetch(PDO::FETCH_ASSOC);

                    if (!$kelas) {
                        $gagal++;
                        continue;
                    }

                    $kelas_id = (int) $kelas['id'];

                    // Cek NIS ganda
                    $stmtCekNis->execute([$nis]);

                    if ($stmtCekNis->fetch()) {
                        $gagal++;
                        continue;
                    }

                    // Cek username ganda
                    $stmtCekUser->execute([$username]);

                    if ($stmtCekUser->fetch()) {
                        $gagal++;
                        continue;
                    }

                    // Buat password acak tepat 8 angka
                    $password = (string) random_int(10000000, 99999999);

                    // Simpan data siswa
                    $stmtSiswa->execute([
                        $nis,
                        $nama,
                        $kelas_id
                    ]);

                    $siswa_id = $pdo->lastInsertId();

                    // Enkripsi password
                    $passwordHash = password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );

                    // Simpan akun siswa
                    $stmtAkun->execute([
                        $siswa_id,
                        $username,
                        $passwordHash
                    ]);

                    // Simpan data login untuk file hasil import
                    $akunBerhasil[] = [
                        'nis' => $nis,
                        'nama' => $nama,
                        'kelas' => $nama_kelas,
                        'username' => $username,
                        'password' => $password
                    ];

                    $berhasil++;
                }

                fclose($handle);

                // Simpan seluruh data jika proses berhasil
                $pdo->commit();

                // Buat file CSV berisi seluruh akun
                if ($berhasil > 0) {

                    $fileAkun = tempnam(
                        sys_get_temp_dir(),
                        'akun_siswa_'
                    );

                    if ($fileAkun === false) {
                        throw new Exception(
                            'Data berhasil diimport, tetapi file akun gagal dibuat. Jangan import ulang sebelum memeriksa database.'
                        );
                    }

                    chmod($fileAkun, 0600);

                    $output = fopen($fileAkun, 'w');

                    // BOM agar Excel membaca UTF-8
                    fwrite($output, "\xEF\xBB\xBF");

                    // Header file akun
                    fputcsv($output, [
                        'NIS',
                        'Nama Siswa',
                        'Kelas',
                        'Username',
                        'Password'
                    ]);

                    // Masukkan semua akun
                    foreach ($akunBerhasil as $akun) {

                        fputcsv($output, [
                            $akun['nis'],
                            $akun['nama'],
                            $akun['kelas'],
                            $akun['username'],
                            $akun['password']
                        ]);
                    }

                    fclose($output);

                    // Simpan lokasi file untuk didownload admin
                    $_SESSION['file_akun_siswa'] = $fileAkun;
                }

                $pesan = "Import selesai! Berhasil: $berhasil siswa beserta akun. Gagal/duplikat: $gagal siswa.";
                $jenis = 'success';

            } catch (Throwable $e) {

                if (isset($handle) && is_resource($handle)) {
                    fclose($handle);
                }

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                $pesan = $e instanceof PDOException
                    ? 'Import gagal! Periksa struktur database, NIS, dan username.'
                    : $e->getMessage();

                $jenis = 'danger';
            }
        }

    } else {

        $pesan = 'Silakan pilih file CSV terlebih dahulu!';
        $jenis = 'danger';
    }
}

// Ambil daftar kelas
$kelas_list = $pdo->query("
    SELECT id, nama_kelas
    FROM kelas
    ORDER BY nama_kelas
")->fetchAll();

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Import Siswa - SMK Muhammadiyah 2 Yogyakarta</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body {
    background: linear-gradient(
        135deg,
        #1e3a8a 0%,
        #2563eb 50%,
        #60a5fa 100%
    );

    min-height: 100vh;
    color: #1e293b;
}

.custom-container {
    max-width: 650px;
}

.card {
    border: none;
    border-radius: 14px;

    box-shadow: 0 10px 25px rgba(0,0,0,.15);

    background-color: #ffffff;
}

.back-link {
    color: #e2e8f0;
    text-decoration: none;
    font-weight: 500;
    display: inline-block;
    margin-bottom: 15px;
}

.back-link:hover {
    color: #ffffff;
    text-decoration: underline;
}

h3 {
    color: #ffffff;
    font-weight: 700;
}

</style>

</head>

<body>

<div class="container custom-container py-5">

<a href="admin.siswa.php" class="back-link">
← Kembali ke Data Siswa
</a>

<h3 class="my-3">Import Data Siswa (CSV)</h3>

<?php if ($pesan): ?>

<div class="alert alert-<?= e($jenis) ?> shadow-sm">

<?= e($pesan) ?>

</div>

<?php endif; ?>


<?php if (!empty($_SESSION['file_akun_siswa']) && is_file($_SESSION['file_akun_siswa'])): ?>

<div class="card p-4 mb-4 border border-success">

<h5 class="text-success fw-bold">
<escape>🎉</escape> Semua Akun Berhasil Dibuat!
</h5>

<p class="text-muted mb-3">
Download file berikut untuk mendapatkan username dan password seluruh siswa yang baru diimport.
</p>

<a href="admin.import.siswa.php?download_akun=1"
class="btn btn-success fw-semibold">

📥 Download Semua Akun Siswa

</a>

<p class="small text-muted mt-3 mb-0">
File berisi NIS, nama, kelas, username, dan password masing-masing siswa.
</p>

</div>

<?php endif; ?>


<div class="card p-4 shadow-sm">

<h5 class="text-primary fw-bold mb-3">
📁 Upload File CSV Siswa
</h5>

<p class="text-muted small">

Siapkan file Excel lalu simpan sebagai format
<strong>CSV (Comma Delimited)</strong>.

<br><br>

Urutan kolom wajib:

<br>

<code>NIS | Nama Lengkap | Nama Kelas</code>

<br><br>

Baris pertama dianggap sebagai header/judul.

<br><br>

<strong>Catatan Penting:</strong>

<ul class="mb-0 ps-3">

<li>
Username setiap siswa otomatis menggunakan NIS.
</li>

<li>
Password dibuat secara acak sebanyak 12 angka.
</li>

<li>
Password disimpan dalam bentuk hash.
</li>

<li>
Siswa yang NIS-nya sudah terdaftar akan dilewati.
</li>

<li>
Nama kelas harus sama persis dengan nama kelas di database.
</li>

<li>
Kolom username dan password tidak perlu disiapkan di Excel.
</li>

</ul>

</p>


<hr>

<h6 class="fw-bold text-primary">
Contoh format CSV:
</h6>

<div class="table-responsive">

<table class="table table-bordered table-sm">

<thead class="table-light">

<tr>
<th>NIS</th>
<th>Nama Lengkap</th>
<th>Nama Kelas</th>
</tr>

</thead>

<tbody>

<tr>
<td>101011</td>
<td>Satria</td>
<td>X TJKT</td>
</tr>


</tbody>

</table>

</div>


<form method="POST" enctype="multipart/form-data" class="mt-3">

<input
type="hidden"
name="csrf"
value="<?= e(csrfToken()) ?>"
>

<div class="mb-3">

<label class="form-label fw-semibold">
Pilih File CSV
</label>

<input
type="file"
name="file_excel"
class="form-control"
accept=".csv"
required
>

</div>

<button
type="submit"
class="btn btn-success px-4 fw-semibold"
onclick="return confirm('Import semua siswa dan buat akun otomatis?')"
>

🚀 Proses Import Siswa

</button>

</form>

</div>

</div>

</body>

</html>