<?php
require_once __DIR__ . '/kunci_password.php';

function enkripsiPasswordGuru($password) {
    $key = hash('sha256', KUNCI_PASSWORD, true);
    $iv = random_bytes(12);
    $tag = '';
    $cipher = openssl_encrypt($password, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
    if ($cipher === false) throw new Exception('Enkripsi password gagal.');
    return base64_encode($iv . $tag . $cipher);
}

function dekripsiPasswordGuru($data) {
    if (!$data) return 'Belum tersedia';
    $raw = base64_decode($data, true);
    if ($raw === false || strlen($raw) < 29) return 'Tidak dapat dibaca';
    $hasil = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', hash('sha256', KUNCI_PASSWORD, true), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
    return $hasil === false ? 'Tidak dapat dibaca' : $hasil;
}

function buatPasswordGuru() {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
    $out = '';
    for ($i = 0; $i < 12; $i++) $out .= $chars[random_int(0, strlen($chars) - 1)];
    return $out;
}

function buatUsernameGuru($nama, $pdo) {
    $base = strtolower(trim($nama));
    if (function_exists('iconv')) {
        $converted = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $base);
        if ($converted !== false) $base = $converted;
    }
    $base = trim(preg_replace('/[^a-z0-9]+/', '.', $base), '.');
    if ($base === '') $base = 'guru';
    $candidate = $base; $n = 1;
    $check = $pdo->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
    do { $check->execute([$candidate]); if (!$check->fetch()) return $candidate; $candidate = $base . ++$n; } while (true);
}

function buatAkunGuruOtomatis($nbm, $nama, $pdo) {
    $nbm = trim((string)$nbm);
    $nama = trim($nama);
    if ($nbm === '' || $nama === '') throw new Exception('NBM dan nama guru wajib diisi.');
    $cekNbm = $pdo->prepare("SELECT id FROM users WHERE nbm = ? AND role = 'guru' LIMIT 1");
    $cekNbm->execute([$nbm]);
    if ($cekNbm->fetch()) throw new Exception('NBM sudah terdaftar.');
    $username = $nbm;
    $cekUsername = $pdo->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
    $cekUsername->execute([$username]);
    if ($cekUsername->fetch()) throw new Exception('NBM ini sudah digunakan sebagai username.');
    $password = buatPasswordGuru();
    $stmt = $pdo->prepare("INSERT INTO users (nbm, nama, username, password, password_terenkripsi, role) VALUES (?, ?, ?, ?, ?, 'guru')");
    $stmt->execute([$nbm, $nama, $username, password_hash($password, PASSWORD_DEFAULT), enkripsiPasswordGuru($password)]);
    return ['id' => $pdo->lastInsertId(), 'nbm' => $nbm, 'username' => $username, 'password' => $password];
}

function resetPasswordGuruOtomatis($id, $pdo) {
    $password = buatPasswordGuru();
    $stmt = $pdo->prepare("UPDATE users SET password = ?, password_terenkripsi = ? WHERE id = ? AND role = 'guru'");
    $stmt->execute([password_hash($password, PASSWORD_DEFAULT), enkripsiPasswordGuru($password), $id]);
    if (!$stmt->rowCount()) {
        $cek = $pdo->prepare("SELECT id FROM users WHERE id = ? AND role = 'guru'"); $cek->execute([$id]);
        if (!$cek->fetch()) throw new Exception('Guru tidak ditemukan.');
    }
    return $password;
}
