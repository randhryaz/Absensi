<?php
require_once 'config.koneksi.php';
wajibRole('admin');

$pesan = '';

$rahasia = 'GANTI_DENGAN_KUNCI_RAHASIA_UNIK_MILIK_LU';
$kunci = hash('sha256', $rahasia, true);
function enkripsiPassword($password, $kunci) {
    $iv = random_bytes(12);
    $tag = '';

    $cipher = openssl_encrypt(
        $password,
        'aes-256-gcm',
        $kunci,
        OPENSSL_RAW_DATA,
        $iv,
        $tag
    );

    if ($cipher === false) {
        throw new Exception('Enkripsi gagal!');
    }

    return base64_encode($iv . $tag . $cipher);
}

function dekripsiPassword($data, $kunci) {
    if (empty($data)) {
        return 'Belum tersedia';
    }

    $decoded = base64_decode($data, true);

    if ($decoded === false || strlen($decoded) < 29) {
        return 'Tidak dapat dibaca';
    }

    $iv = substr($decoded, 0, 12);
    $tag = substr($decoded, 12, 16);
    $cipher = substr($decoded, 28);

    $hasil = openssl_decrypt(
        $cipher,
        'aes-256-gcm',
        $kunci,
        OPENSSL_RAW_DATA,
        $iv,
        $tag
    );

    return $hasil !== false ? $hasil : 'Tidak dapat dibaca';
}

/* PROSES BUAT / PERBARUI AKUN */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cekCsrf();

    $siswa_id = (int)($_POST['siswa_id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($siswa_id <= 0 || $username === '') {
        $pesan = 'Pilih siswa dan isi username!';
    } elseif (strlen($password) < 8) {
        $pesan = 'Password minimal 8 karakter!';
    } else {
        try {
            // Pastikan siswa benar-benar ada
            $cekSiswa = $pdo->prepare(
                "SELECT id FROM siswa WHERE id = ?"
            );
            $cekSiswa->execute([$siswa_id]);

            if (!$cekSiswa->fetch()) {
                throw new Exception('Siswa tidak ditemukan!');
            }

            // Cek username milik akun siswa LAIN
            $cek = $pdo->prepare("
                SELECT id FROM akun_siswa
                WHERE username = ? AND siswa_id != ?

                UNION

                SELECT id FROM users
                WHERE username = ?
            ");

            $cek->execute([
                $username,
                $siswa_id,
                $username
            ]);

            if ($cek->fetch()) {
                $pesan = 'Username sudah digunakan!';
            } else {
                $hash = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                $terenkripsi = enkripsiPassword(
                    $password,
                    $kunci
                );

                // Cek apakah siswa sudah punya akun
                $cekAkun = $pdo->prepare("
                    SELECT id FROM akun_siswa
                    WHERE siswa_id = ?
                ");
                $cekAkun->execute([$siswa_id]);

                $akunLama = $cekAkun->fetch();

                if ($akunLama) {
                    // Perbarui akun yang sudah ada
                    $stmt = $pdo->prepare("
                        UPDATE akun_siswa
                        SET username = ?,
                            password = ?,
                            password_terenkripsi = ?
                        WHERE siswa_id = ?
                    ");

                    $stmt->execute([
                        $username,
                        $hash,
                        $terenkripsi,
                        $siswa_id
                    ]);

                    $pesan = 'Akun siswa berhasil diperbarui!';
                } else {
                    // Buat akun baru
                    $stmt = $pdo->prepare("
                        INSERT INTO akun_siswa
                        (siswa_id, username, password, password_terenkripsi)
                        VALUES (?, ?, ?, ?)
                    ");

                    $stmt->execute([
                        $siswa_id,
                        $username,
                        $hash,
                        $terenkripsi
                    ]);

                    $pesan = 'Akun siswa berhasil dibuat!';
                }
            }

        } catch (PDOException $e) {
            $pesan = 'Gagal menyimpan akun. Periksa database!';
        } catch (Exception $e) {
            $pesan = $e->getMessage();
        }
    }
}

/*
|--------------------------------------------------------------------------
| OTOMATIS MEMBUAT PASSWORD UNTUK AKUN LAMA
|--------------------------------------------------------------------------
*/

try {
    $akunLama = $pdo->query("
        SELECT id
        FROM akun_siswa
        WHERE password_terenkripsi IS NULL
        OR password_terenkripsi = ''
    ")->fetchAll();

    $updatePassword = $pdo->prepare("
        UPDATE akun_siswa
        SET password = ?,
            password_terenkripsi = ?
        WHERE id = ?
    ");

    foreach ($akunLama as $akun) {

        // Password baru acak 12 karakter
        $passwordBaru = bin2hex(random_bytes(6));

        // Simpan hash untuk proses login
        $hash = password_hash(
            $passwordBaru,
            PASSWORD_DEFAULT
        );

        // Simpan versi terenkripsi untuk ditampilkan admin
        $terenkripsi = enkripsiPassword(
            $passwordBaru,
            $kunci
        );

        $updatePassword->execute([
            $hash,
            $terenkripsi,
            $akun['id']
        ]);
    }

} catch (PDOException $e) {
    die('Gagal memperbarui password akun siswa. Periksa database.');
}

/* AMBIL SEMUA SISWA - TERMASUK YANG SUDAH PUNYA AKUN */

$siswa = $pdo->query("
    SELECT
        s.id,
        s.nama,
        s.nis,
        k.nama_kelas
    FROM siswa s
    JOIN kelas k ON k.id = s.kelas_id
    ORDER BY s.nama
")->fetchAll();

/* AMBIL DAFTAR AKUN */

$data = $pdo->query("
    SELECT
        a.username,
        a.password_terenkripsi,
        s.nama,
        s.nis,
        k.nama_kelas
    FROM akun_siswa a
    JOIN siswa s ON s.id = a.siswa_id
    JOIN kelas k ON k.id = s.kelas_id
    ORDER BY s.nama
")->fetchAll();

?>

<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Akun Siswa</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(
        135deg,
        #1e3a8a 0%,
        #2563eb 50%,
        #60a5fa 100%
    );
    min-height: 100vh;
    color: #1e293b;
}

.custom-container {
    max-width: 1000px;
}

.card {
    border: none;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0,0,0,.15);
    background-color: #fff;
}

h3, h5 {
    color: #fff;
}

.back-link {
    color: #e2e8f0;
    text-decoration: none;
    font-weight: 500;
    display: inline-block;
    margin-bottom: 10px;
}

.back-link:hover {
    color: #fff;
    text-decoration: underline;
}

.password-cell {
    font-family: monospace;
    font-weight: 600;
    color: #15803d;
    white-space: nowrap;
}
</style>

</head>

<body>

<div class="container custom-container py-5">

<a href="admin.dashboard.php" class="back-link" style="display:inline-block;background:#dc3545;color:#fff;text-decoration:none;padding:7px 13px;border-radius:6px;width:fit-content;margin-bottom:15px;font-weight:500">← Kembali</a>

<h3 class="my-3 fw-bold">Akun Login Siswa</h3>

<?php if ($pesan): ?>
<div class="alert alert-info shadow-sm">
    <?= e($pesan) ?>
</div>
<?php endif; ?>


<div class="card p-4 mb-4">

<h5 class="text-dark fw-bold mb-3">
    Buat / Perbarui Akun Siswa
</h5>

<form method="POST">

<input
    type="hidden"
    name="csrf"
    value="<?= e(csrfToken()) ?>"
>

<div class="mb-3">

<select name="siswa_id" class="form-select" required>

<option value="">Pilih siswa</option>

<?php foreach ($siswa as $s): ?>

<option value="<?= (int)$s['id'] ?>">

<?= e($s['nama']) ?> -
<?= e($s['nis']) ?>
(<?= e($s['nama_kelas']) ?>)

</option>

<?php endforeach; ?>

</select>

</div>

<div class="mb-3">

<input
    name="username"
    class="form-control"
    placeholder="Username siswa"
    required
>

</div>

<div class="mb-3">

<div class="input-group">

<input
    name="password"
    id="password"
    type="password"
    minlength="8"
    class="form-control"
    placeholder="Password minimal 8 karakter"
    required
>

<button
    type="button"
    class="btn btn-outline-secondary"
    onclick="togglePassword()"
>
    👁
</button>

</div>

</div>

<button class="btn btn-primary px-4 fw-semibold">
    Simpan Akun
</button>

</form>
</div>


<div class="card p-4">

<h5 class="text-dark fw-bold mb-3">
    Daftar Akun Siswa
</h5>

<div class="table-responsive">

<table class="table table-hover align-middle">

<thead class="table-light">
<tr>
    <th>Nama</th>
    <th>NIS</th>
    <th>Kelas</th>
    <th>Username</th>
    <th>Password</th>
</tr>
</thead>

<tbody>

<?php foreach ($data as $a): ?>

<tr>

<td><?= e($a['nama']) ?></td>

<td><?= e($a['nis']) ?></td>

<td><?= e($a['nama_kelas']) ?></td>

<td>
    <span class="badge bg-primary">
        <?= e($a['username']) ?>
    </span>
</td>

<td class="password-cell">
    <?= e(dekripsiPassword(
        $a['password_terenkripsi'],
        $kunci
    )) ?>
</td>

</tr>

<?php endforeach; ?>

<?php if (empty($data)): ?>

<tr>
    <td colspan="5" class="text-center text-muted py-3">
        Belum ada akun siswa.
    </td>
</tr>

<?php endif; ?>

</tbody>
</table>

</div>
</div>

</div>

<script>
function togglePassword() {
    const input = document.getElementById('password');

    input.type = input.type === 'password'
        ? 'text'
        : 'password';
}
</script>

</body>
</html>
