<?php
require_once 'config.koneksi.php';
require_once 'fungsi.akun.guru.php';
wajibRole('admin');
$pesan = ''; $jenis = 'info';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cekCsrf();
    try {
        $id = (int)($_POST['guru_id'] ?? 0);
        if ($id <= 0) throw new Exception('Guru tidak valid.');
        $passwordBaru = resetPasswordGuruOtomatis($id, $pdo);
        $_SESSION['password_guru_reset'] = ['id'=>$id, 'password'=>$passwordBaru];
        header('Location: admin.akun.guru.php?reset=1'); exit;
    } catch (Throwable $e) { $pesan = $e->getMessage(); $jenis = 'danger'; }
}
if (isset($_GET['reset'])) { $pesan = 'Password berhasil direset. Catat password baru yang ditampilkan.'; $jenis = 'success'; }
$data = $pdo->query("SELECT id,nbm,nama,username,password_terenkripsi FROM users WHERE role='guru' ORDER BY nama")->fetchAll();
$resetInfo = $_SESSION['password_guru_reset'] ?? null; unset($_SESSION['password_guru_reset']);
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Akun Login Guru</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><style>body{background:linear-gradient(135deg,#1e3a8a,#2563eb,#60a5fa);min-height:100vh}.wrap{max-width:1000px}.card{border:0;border-radius:14px}h3{color:white}.back{display:inline-block;background:#dc3545;color:#fff;text-decoration:none;padding:7px 13px;border-radius:6px}.back:hover{background:#bb2d3b;color:#fff}.pw{font-family:monospace;color:#15803d;font-weight:600;white-space:nowrap}</style></head><body><div class="container wrap py-5"><a class="back back-link" href="admin.dashboard.php" style="display:inline-block;background:#dc3545;color:#fff;text-decoration:none;padding:7px 13px;border-radius:6px;width:fit-content;margin-bottom:15px;font-weight:500">← Kembali</a><h3 class="my-3 fw-bold">Akun Login Guru</h3>
<?php if($pesan): ?><div class="alert alert-<?= e($jenis) ?>"><?= e($pesan) ?></div><?php endif; ?>
<?php if($resetInfo): ?><div class="alert alert-warning"><strong>Password baru:</strong> <code><?= e($resetInfo['password']) ?></code><br>Segera salin dan berikan kepada guru.</div><?php endif; ?>
<div class="card p-4"><div class="d-flex justify-content-between align-items-center mb-3"><h5 class="text-primary fw-bold mb-0">Daftar Akun Guru</h5><a href="admin.guru.php" class="btn btn-outline-primary btn-sm">Data Guru</a></div><div class="table-responsive"><table class="table table-hover align-middle"><thead class="table-light"><tr><th>No</th><th>NBM</th><th>Nama Guru</th><th>Username</th><th>Password</th><th>Aksi</th></tr></thead><tbody>
<?php foreach($data as $i=>$g): $pw=dekripsiPasswordGuru($g['password_terenkripsi']); ?><tr><td><?= $i+1 ?></td><td><?= e($g['nbm'] ?? '-') ?></td><td><?= e($g['nama']) ?></td><td><span class="badge bg-primary"><?= e($g['username']) ?></span></td><td class="pw"><?= e($pw) ?></td><td><div class="d-flex gap-1"><button type="button" class="btn btn-sm btn-outline-primary" onclick='salinAkun(<?= json_encode($g['username']) ?>,<?= json_encode($pw) ?>)'>Salin</button><form method="POST" onsubmit="return confirm('Reset password guru ini?')"><input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>"><input type="hidden" name="guru_id" value="<?= (int)$g['id'] ?>"><button class="btn btn-sm btn-warning">Reset</button></form></div></td></tr><?php endforeach; ?>
<?php if(!$data): ?><tr><td colspan="6" class="text-center text-muted">Belum ada akun guru.</td></tr><?php endif; ?></tbody></table></div></div></div><script>function salinAkun(u,p){navigator.clipboard.writeText('Username: '+u+'\nPassword: '+p).then(()=>alert('Akun berhasil disalin.')).catch(()=>alert('Gagal menyalin.'));}</script></body></html>
