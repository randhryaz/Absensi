<?php
require 'config.koneksi.php';
wajibRole('admin');

$pesan = '';
$jenis = 'info';

if (isset($_GET['berhasil'])) {
    $pesan = match($_GET['berhasil']) {
        'tambah' => 'Data kelas baru berhasil ditambahkan!',
        'edit'   => 'Data kelas berhasil diperbarui!',
        'hapus'  => 'Data kelas berhasil dihapus!',
        default  => 'Operasi berhasil dilakukan.'
    };
    $jenis = 'success';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cekCsrf();

    try {
        if (isset($_POST['tambah'])) {
            $nama_kelas = trim($_POST['nama_kelas']);
            $guru = $_POST['guru_id'] !== '' ? (int)$_POST['guru_id'] : null;

            if ($nama_kelas === '') {
                throw new Exception("Nama kelas tidak boleh kosong!");
            }

            $stmt = $pdo->prepare("INSERT INTO kelas(nama_kelas, guru_id) VALUES(?, ?)");
            $stmt->execute([$nama_kelas, $guru]);

            header("Location: admin.kelas.php?berhasil=tambah");
            exit;
        }

        elseif (isset($_POST['edit'])) {
            $id = (int)$_POST['id'];
            $nama_kelas = trim($_POST['nama_kelas']);
            $guru = $_POST['guru_id'] !== '' ? (int)$_POST['guru_id'] : null;

            if ($nama_kelas === '') {
                throw new Exception("Nama kelas tidak boleh kosong!");
            }

            $stmt = $pdo->prepare("UPDATE kelas SET nama_kelas = ?, guru_id = ? WHERE id = ?");
            $stmt->execute([$nama_kelas, $guru, $id]);
            
            header("Location: admin.kelas.php?berhasil=edit");
            exit;
        }

        // FITUR HAPUS BANYAK (MASSAL)
        elseif (isset($_POST['hapus_banyak'])) {
            $ids = array_values(array_unique(array_filter(
                array_map('intval', $_POST['pilih'] ?? []),
                fn($id) => $id > 0
            )));

            if (!$ids) {
                throw new Exception('Pilih kelas terlebih dahulu!');
            }

            $pdo->beginTransaction();
            $terhapus = 0;
            $gagal = 0;

            foreach ($ids as $id) {
                // Cek apakah kelas masih memiliki siswa
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM siswa WHERE kelas_id = ?");
                $stmt->execute([$id]);

                if ($stmt->fetchColumn() > 0) {
                    $gagal++;
                    continue;
                }

                $pdo->prepare("DELETE FROM kelas WHERE id = ?")->execute([$id]);
                $terhapus++;
            }

            $pdo->commit();

            if ($gagal > 0) {
                $pesan = "Berhasil menghapus $terhapus kelas. $gagal kelas dilewati karena masih memiliki siswa.";
                $jenis = 'warning';
            } else {
                header("Location: admin.kelas.php?berhasil=hapus");
                exit;
            }
        }

        // FITUR HAPUS SATUAN
        elseif (isset($_POST['hapus'])) {
            $id = (int)$_POST['hapus'];

            $stmt = $pdo->prepare("SELECT COUNT(*) FROM siswa WHERE kelas_id = ?");
            $stmt->execute([$id]);

            if ($stmt->fetchColumn() > 0) {
                throw new Exception("Gagal menghapus! Kelas ini masih memiliki siswa.");
            }

            $pdo->prepare("DELETE FROM kelas WHERE id = ?")->execute([$id]);

            header("Location: admin.kelas.php?berhasil=hapus");
            exit;
        }

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $pesan = "Gagal: " . $e->getMessage();
        $jenis = 'danger';
    }
}

$guru = $pdo->query("SELECT id, nama FROM users WHERE role='guru' ORDER BY nama")->fetchAll();

$data = $pdo->query("
    SELECT k.*, u.nama AS nama_guru
    FROM kelas k 
    LEFT JOIN users u ON u.id = k.guru_id
    ORDER BY k.nama_kelas
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Data Kelas - SMK MUHAYO</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #60a5fa 100%);
        min-height: 100vh;
        color: #1e293b;
    }
    .custom-container {
        max-width: 1000px;
    }
    .card {
        border: none;
        border-radius: 14px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        background-color: #ffffff;
    }
    .back-link {
        color: #e2e8f0;
        text-decoration: none;
        font-weight: 500;
        display: inline-block;
        margin-bottom: 15px;
        transition: color 0.2s;
    }
    .back-link:hover {
        color: #ffffff;
        text-decoration: underline;
    }
    h3 {
        color: #ffffff;
        font-weight: 700;
    }
    .table-container {
        background: #ffffff;
        border-radius: 10px;
        overflow: hidden;
    }
</style>
</head>
<body class="bg-light">

<div class="container custom-container py-5">
<a href="admin.dashboard.php" class="back-link" style="display:inline-block;background:#dc3545;color:#fff;text-decoration:none;padding:7px 13px;border-radius:6px;width:fit-content;margin-bottom:15px;font-weight:500">← Kembali</a>
<h3 class="my-3">Data Kelas</h3>

<?php if($pesan): ?>
<div class="alert alert-<?= e($jenis) ?> shadow-sm"><?= e($pesan) ?></div>
<?php endif; ?>

<div class="card shadow-sm p-4 mb-4">
<h5 class="text-primary fw-bold mb-3">➕ Tambah Kelas Baru</h5>
<form method="POST">
<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">
<div class="mb-2">
<input name="nama_kelas" class="form-control" placeholder="Contoh: X RPL 1" required>
</div>
<div class="mb-3">
<select name="guru_id" class="form-select">
<option value="">Pilih wali kelas</option>
<?php foreach($guru as $g): ?>
<option value="<?= (int)$g['id'] ?>"><?= e($g['nama']) ?></option>
<?php endforeach; ?>
</select>
</div>
<button name="tambah" class="btn btn-primary px-4 fw-semibold">Tambah Kelas</button>
</form>
</div>

<div class="card shadow-sm p-4">
<h5 class="text-primary fw-bold mb-3">📋 Daftar Kelas</h5>

<form method="POST" id="formHapus">
<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">

<div class="d-flex gap-2 flex-wrap mb-3">
<button name="hapus_banyak" value="1" class="btn btn-danger btn-sm px-3 fw-semibold" onclick="return konfirmasiHapus()">Hapus Kelas Terpilih</button>
<button type="button" class="btn btn-outline-primary btn-sm px-3 fw-semibold" onclick="pilihSemua()">Pilih Semua</button>
<button type="button" class="btn btn-outline-secondary btn-sm px-3 fw-semibold" onclick="batalkanPilihan()">Batalkan Pilihan</button>
</div>

<div class="table-responsive table-container">
<table class="table table-hover align-middle mb-0">
<thead class="table-light">
<tr>
<th style="width: 40px;"><input type="checkbox" id="semua" onchange="toggleSemua(this)"></th>
<th>Kelas</th>
<th>Wali Kelas</th>
<th class="text-end" style="width: 180px;">Aksi</th>
</tr>
</thead>
<tbody>

<?php foreach($data as $k): ?>
<tr>
<td><input type="checkbox" class="pilih" name="pilih[]" value="<?= (int)$k['id'] ?>"></td>
<td class="fw-semibold"><?= e($k['nama_kelas']) ?></td>
<td>
<?php if(!empty($k['nama_guru'])): ?>
<span class="badge bg-secondary"><?= e($k['nama_guru']) ?></span>
<?php else: ?>
<span class="text-muted small">Belum ditentukan</span>
<?php endif; ?>
</td>
<td class="text-end text-nowrap">
<button type="button" class="btn btn-warning btn-sm px-2 py-1 text-dark fw-semibold" data-bs-toggle="collapse" data-bs-target="#edit<?= (int)$k['id'] ?>">Edit</button>

<button type="submit" form="formHapus" name="hapus" value="<?= (int)$k['id'] ?>" class="btn btn-danger btn-sm px-2 py-1" onclick="return confirm('Yakin ingin menghapus kelas ini?')">Hapus</button>
</td>
</tr>

<tr class="collapse bg-light" id="edit<?= (int)$k['id'] ?>">
<td colspan="4">
<div class="p-3 border rounded bg-white my-2">
<form method="POST">
<input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">
<input type="hidden" name="id" value="<?= (int)$k['id'] ?>">

<div class="mb-2">
<label class="form-label fw-semibold">Nama Kelas</label>
<input name="nama_kelas" class="form-control" value="<?= e($k['nama_kelas']) ?>" required>
</div>

<div class="mb-3">
<label class="form-label fw-semibold">Wali Kelas</label>
<select name="guru_id" class="form-select">
<option value="">Pilih wali kelas</option>
<?php foreach($guru as $g): ?>
<option value="<?= (int)$g['id'] ?>" <?= $k['guru_id'] == $g['id'] ? 'selected' : '' ?>>
<?= e($g['nama']) ?>
</option>
<?php endforeach; ?>
</select>
</div>

<button type="submit" name="edit" class="btn btn-success px-4 fw-semibold">Simpan Perubahan</button>
</form>
</div>
</td>
</tr>
<?php endforeach; ?>

<?php if(!$data): ?>
<tr><td colspan="4" class="text-center text-muted py-3">Belum ada data kelas.</td></tr>
<?php endif; ?>

</tbody>
</table>
</div>
</form>
</div>
</div>

<script>
function toggleSemua(el){document.querySelectorAll('.pilih').forEach(c=>c.checked=el.checked);}
function pilihSemua(){document.querySelectorAll('.pilih').forEach(c=>c.checked=true);document.getElementById('semua').checked=true;}
function batalkanPilihan(){document.querySelectorAll('.pilih').forEach(c=>c.checked=false);document.getElementById('semua').checked=false;}
function konfirmasiHapus(){
 const n = document.querySelectorAll('.pilih:checked').length;
 if(!n){alert('Pilih kelas terlebih dahulu!');return false;}
 return confirm('Yakin ingin menghapus '+n+' kelas yang dipilih?');
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>